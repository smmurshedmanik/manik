
import React, { useState, useEffect } from 'react';
import { useLocation, useSearchParams } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import POSHeader from '@/components/POSHeader';
import NewSale from '@/components/sales/NewSale';
import SalesList from '@/components/sales/SalesList';
import CustomerManager from '@/components/sales/CustomerManager';

const Sales = () => {
  const [activeTab, setActiveTab] = useState('new-sale');
  const [searchParams] = useSearchParams();

  useEffect(() => {
    const tab = searchParams.get('tab');
    if (tab && ['new-sale', 'sales-list', 'customers'].includes(tab)) {
      setActiveTab(tab);
    }
  }, [searchParams]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      <POSHeader />
      
      <main className="w-full px-2 sm:px-4 lg:px-6 py-4 sm:py-8">
        <div className="mb-4 sm:mb-6">
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-800 bangla-text mb-2">
            বিক্রয় ব্যবস্থাপনা
          </h1>
          <p className="text-sm sm:text-base text-gray-600 bangla-text">
            নতুন বিক্রয়, ইনভয়েস তৈরি এবং পেমেন্ট পরিচালনা করুন
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-white shadow-sm text-sm sm:text-base">
            <TabsTrigger value="new-sale" className="bangla-text">নতুন বিক্রয়</TabsTrigger>
            <TabsTrigger value="sales-list" className="bangla-text">বিক্রয় তালিকা</TabsTrigger>
            <TabsTrigger value="customers" className="bangla-text">গ্রাহক</TabsTrigger>
          </TabsList>

          <TabsContent value="new-sale" className="mt-6">
            <NewSale onSuccess={() => setActiveTab('sales-list')} />
          </TabsContent>

          <TabsContent value="sales-list" className="mt-6">
            <SalesList />
          </TabsContent>

          <TabsContent value="customers" className="mt-6">
            <CustomerManager />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Sales;
