import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, BarChart3, PieChart, Calendar, DollarSign, Package2, Users, Receipt, ArrowUp, ArrowDown } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import POSHeader from '@/components/POSHeader';

const Reports = () => {
  const [dateRange, setDateRange] = useState({
    from: new Date().toISOString().split('T')[0],
    to: new Date().toISOString().split('T')[0]
  });

  // Function to convert English numbers to Bengali
  const toBengaliNumber = (num: number) => {
    const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return num.toString().replace(/\d/g, (digit) => bengaliDigits[parseInt(digit)]);
  };

  // Get sales data
  const { data: salesData = [] } = useQuery({
    queryKey: ['sales-report', dateRange],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('sales')
        .select('*')
        .gte('created_at', `${dateRange.from}T00:00:00.000Z`)
        .lte('created_at', `${dateRange.to}T23:59:59.999Z`)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data;
    },
  });

  // Get products data
  const { data: productsData = [] } = useQuery({
    queryKey: ['products-report'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('*, categories(name), brands(name)')
        .order('current_stock', { ascending: true });
      
      if (error) throw error;
      return data;
    },
  });

  // Calculate statistics
  const totalSales = salesData.reduce((sum, sale) => sum + sale.total_amount, 0);
  const totalTransactions = salesData.length;
  const paidAmount = salesData.reduce((sum, sale) => sum + sale.paid_amount, 0);
  const dueAmount = salesData.reduce((sum, sale) => sum + sale.due_amount, 0);
  const lowStockProducts = productsData.filter(product => product.current_stock <= product.min_stock);

  // Calculate percentage changes (mock data for demo)
  const salesGrowth = 12.5;
  const transactionGrowth = 8.3;
  const paidGrowth = 15.2;
  const dueGrowth = -5.7;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      <POSHeader />
      
      <main className="w-full px-2 sm:px-4 lg:px-6 py-4 sm:py-8">
        <div className="mb-4 sm:mb-6">
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-800 bangla-text mb-2">
            রিপোর্ট এবং অ্যানালিটিক্স
          </h1>
          <p className="text-sm sm:text-base text-gray-600 bangla-text">
            বিক্রয়, মুনাফা এবং ব্যবসায়িক পরিসংখ্যান দেখুন
          </p>
        </div>

        {/* Enhanced Date Range Selector */}
        <Card className="pos-card border-0 mb-6 bg-gradient-to-r from-blue-50 to-purple-50">
          <CardHeader>
            <CardTitle className="text-lg font-bold text-gray-800 bangla-text flex items-center">
              <Calendar className="w-5 h-5 mr-2 text-blue-600" />
              তারিখ নির্বাচন করুন
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="block text-sm font-semibold text-gray-700 bangla-text">শুরুর তারিখ</label>
                <Input
                  type="date"
                  value={dateRange.from}
                  onChange={(e) => setDateRange({ ...dateRange, from: e.target.value })}
                  className="border-blue-200 focus:border-blue-500"
                />
              </div>
              <div className="space-y-2">
                <label className="block text-sm font-semibold text-gray-700 bangla-text">শেষের তারিখ</label>
                <Input
                  type="date"
                  value={dateRange.to}
                  onChange={(e) => setDateRange({ ...dateRange, to: e.target.value })}
                  className="border-blue-200 focus:border-blue-500"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4 bg-white shadow-lg border border-gray-200">
            <TabsTrigger value="overview" className="bangla-text font-semibold">সারসংক্ষেপ</TabsTrigger>
            <TabsTrigger value="sales" className="bangla-text font-semibold">বিক্রয় রিপোর্ট</TabsTrigger>
            <TabsTrigger value="products" className="bangla-text font-semibold">পণ্য রিপোর্ট</TabsTrigger>
            <TabsTrigger value="analytics" className="bangla-text font-semibold">অ্যানালিটিক্স</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            {/* Enhanced Statistics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
              <Card className="pos-card border-0 bg-gradient-to-br from-green-50 to-emerald-100 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                        <DollarSign className="w-6 h-6 text-green-600" />
                      </div>
                      <div className="ml-4">
                        <p className="text-sm text-gray-600 bangla-text">মোট বিক্রয়</p>
                        <p className="text-2xl font-bold text-green-600 bangla-text">৳{toBengaliNumber(totalSales)}</p>
                      </div>
                    </div>
                    <div className="flex items-center text-green-600">
                      <ArrowUp className="w-4 h-4" />
                      <span className="text-sm font-medium bangla-text">{toBengaliNumber(salesGrowth)}%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="pos-card border-0 bg-gradient-to-br from-blue-50 to-cyan-100 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <Receipt className="w-6 h-6 text-blue-600" />
                      </div>
                      <div className="ml-4">
                        <p className="text-sm text-gray-600 bangla-text">মোট লেনদেন</p>
                        <p className="text-2xl font-bold text-blue-600 bangla-text">{toBengaliNumber(totalTransactions)}টি</p>
                      </div>
                    </div>
                    <div className="flex items-center text-blue-600">
                      <ArrowUp className="w-4 h-4" />
                      <span className="text-sm font-medium bangla-text">{toBengaliNumber(transactionGrowth)}%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="pos-card border-0 bg-gradient-to-br from-purple-50 to-pink-100 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                        <TrendingUp className="w-6 h-6 text-purple-600" />
                      </div>
                      <div className="ml-4">
                        <p className="text-sm text-gray-600 bangla-text">প্রাপ্ত টাকা</p>
                        <p className="text-2xl font-bold text-purple-600 bangla-text">৳{toBengaliNumber(paidAmount)}</p>
                      </div>
                    </div>
                    <div className="flex items-center text-purple-600">
                      <ArrowUp className="w-4 h-4" />
                      <span className="text-sm font-medium bangla-text">{toBengaliNumber(paidGrowth)}%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="pos-card border-0 bg-gradient-to-br from-orange-50 to-red-100 shadow-lg hover:shadow-xl transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                        <Package2 className="w-6 h-6 text-orange-600" />
                      </div>
                      <div className="ml-4">
                        <p className="text-sm text-gray-600 bangla-text">বকেয়া টাকা</p>
                        <p className="text-2xl font-bold text-orange-600 bangla-text">৳{toBengaliNumber(dueAmount)}</p>
                      </div>
                    </div>
                    <div className="flex items-center text-green-600">
                      <ArrowDown className="w-4 h-4" />
                      <span className="text-sm font-medium bangla-text">{toBengaliNumber(Math.abs(dueGrowth))}%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Enhanced Low Stock Alert */}
            {lowStockProducts.length > 0 && (
              <Card className="pos-card border-0 bg-gradient-to-r from-red-50 to-orange-50 border-l-4 border-l-red-500 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-lg font-bold text-red-700 bangla-text flex items-center">
                    <Package2 className="w-5 h-5 mr-2" />
                    স্টক সতর্কতা
                    <Badge variant="destructive" className="ml-2 bangla-text">
                      {toBengaliNumber(lowStockProducts.length)} টি পণ্য
                    </Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {lowStockProducts.slice(0, 6).map((product) => (
                      <div key={product.id} className="bg-white p-4 rounded-lg border border-red-200 shadow-sm hover:shadow-md transition-shadow">
                        <h4 className="font-semibold bangla-text text-gray-800">{product.name}</h4>
                        <div className="flex justify-between items-center mt-2">
                          <Badge variant="destructive" className="bangla-text">
                            স্টক: {toBengaliNumber(product.current_stock)}
                          </Badge>
                          <span className="text-sm text-gray-600 bangla-text">
                            মিন: {toBengaliNumber(product.min_stock)}
                          </span>
                        </div>
                        <div className="mt-2 bg-red-200 rounded-full h-2">
                          <div 
                            className="bg-red-500 h-2 rounded-full" 
                            style={{ width: `${Math.min((product.current_stock / product.min_stock) * 100, 100)}%` }}
                          ></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="sales" className="mt-6">
            <Card className="pos-card border-0 shadow-lg">
              <CardHeader className="bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-t-lg">
                <CardTitle className="text-lg font-bold bangla-text flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2" />
                  বিক্রয় বিস্তারিত
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <div className="max-h-96 overflow-y-auto">
                  {salesData.map((sale, index) => (
                    <div key={sale.id} className={`flex items-center justify-between p-4 ${index % 2 === 0 ? 'bg-gray-50' : 'bg-white'} hover:bg-blue-50 transition-colors`}>
                      <div>
                        <h4 className="font-semibold bangla-text">{sale.invoice_number}</h4>
                        <p className="text-sm text-gray-600 bangla-text">
                          {sale.customer_name || 'ওয়াক-ইন গ্রাহক'}
                        </p>
                        <p className="text-xs text-gray-500">
                          {new Date(sale.created_at).toLocaleDateString('bn-BD')}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-green-600 bangla-text">৳{toBengaliNumber(sale.total_amount)}</p>
                        <Badge variant={sale.payment_status === 'paid' ? 'default' : 'secondary'} className="bangla-text">
                          {sale.payment_status === 'paid' ? 'পরিশোধিত' : 'বকেয়া'}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="products" className="mt-6">
            <Card className="pos-card border-0">
              <CardHeader>
                <CardTitle className="text-lg font-bold text-gray-800 bangla-text flex items-center">
                  <Package2 className="w-5 h-5 mr-2" />
                  পণ্য স্টক রিপোর্ট
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {productsData.map((product) => (
                    <div key={product.id} className="p-4 bg-gray-50 rounded-lg">
                      <h4 className="font-semibold bangla-text mb-2">{product.name}</h4>
                      <div className="space-y-1 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600 bangla-text">বর্তমান স্টক:</span>
                          <span className="font-semibold bangla-text">{toBengaliNumber(product.current_stock)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 bangla-text">মিন স্টক:</span>
                          <span className="bangla-text">{toBengaliNumber(product.min_stock)}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600 bangla-text">খুচরা দাম:</span>
                          <span className="bangla-text">৳{toBengaliNumber(product.retail_price)}</span>
                        </div>
                      </div>
                      {product.current_stock <= product.min_stock && (
                        <Badge variant="destructive" className="mt-2 bangla-text">কম স্টক</Badge>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Enhanced Payment Method Analysis */}
              <Card className="pos-card border-0 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-green-500 to-teal-600 text-white rounded-t-lg">
                  <CardTitle className="text-lg font-bold bangla-text flex items-center">
                    <PieChart className="w-5 h-5 mr-2" />
                    পেমেন্ট পদ্ধতি বিশ্লেষণ
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {['cash', 'card', 'mobile'].map((method) => {
                      const methodSales = salesData.filter(sale => sale.payment_method === method);
                      const methodTotal = methodSales.reduce((sum, sale) => sum + sale.total_amount, 0);
                      const percentage = totalSales > 0 ? (methodTotal / totalSales * 100) : 0;
                      
                      return (
                        <div key={method} className="bg-gradient-to-r from-gray-50 to-gray-100 p-4 rounded-lg border border-gray-200">
                          <div className="flex items-center justify-between mb-2">
                            <span className="bangla-text font-medium text-gray-800">
                              {method === 'cash' ? 'নগদ' : method === 'card' ? 'কার্ড' : 'মোবাইল'}
                            </span>
                            <div className="text-right">
                              <div className="font-bold bangla-text text-gray-800">৳{toBengaliNumber(methodTotal)}</div>
                              <div className="text-sm text-gray-500 bangla-text">{toBengaliNumber(Math.round(percentage))}%</div>
                            </div>
                          </div>
                          <div className="w-full bg-gray-300 rounded-full h-2">
                            <div 
                              className="bg-gradient-to-r from-green-500 to-teal-600 h-2 rounded-full transition-all duration-300" 
                              style={{ width: `${percentage}%` }}
                            ></div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>

              {/* Enhanced Sales Type Analysis */}
              <Card className="pos-card border-0 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-t-lg">
                  <CardTitle className="text-lg font-bold bangla-text flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2" />
                    বিক্রয়ের ধরন বিশ্লেষণ
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    {['retail', 'wholesale'].map((type) => {
                      const typeSales = salesData.filter(sale => sale.sale_type === type);
                      const typeTotal = typeSales.reduce((sum, sale) => sum + sale.total_amount, 0);
                      const percentage = totalSales > 0 ? (typeTotal / totalSales * 100) : 0;
                      
                      return (
                        <div key={type} className="bg-gradient-to-r from-gray-50 to-gray-100 p-4 rounded-lg border border-gray-200">
                          <div className="flex items-center justify-between mb-2">
                            <span className="bangla-text font-medium text-gray-800">
                              {type === 'retail' ? 'খুচরা' : 'পাইকারি'}
                            </span>
                            <div className="text-right">
                              <div className="font-bold bangla-text text-gray-800">৳{toBengaliNumber(typeTotal)}</div>
                              <div className="text-sm text-gray-500 bangla-text">{toBengaliNumber(Math.round(percentage))}%</div>
                            </div>
                          </div>
                          <div className="w-full bg-gray-300 rounded-full h-2">
                            <div 
                              className="bg-gradient-to-r from-purple-500 to-pink-600 h-2 rounded-full transition-all duration-300" 
                              style={{ width: `${percentage}%` }}
                            ></div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Reports;
