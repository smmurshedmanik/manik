
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Zap, Eye, EyeOff } from 'lucide-react';

const Auth = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<'owner' | 'staff'>('staff');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  useEffect(() => {
    // Check if user is already logged in
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) {
        navigate('/');
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      if (session) {
        navigate('/');
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const handleLogin = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        toast({
          title: 'লগইন ত্রুটি',
          description: error.message === 'Invalid login credentials' 
            ? 'ভুল ইমেইল বা পাসওয়ার্ড' 
            : error.message,
          variant: 'destructive',
        });
      } else {
        toast({
          title: 'সফল!',
          description: 'সফলভাবে লগইন হয়েছে',
        });
      }
    } catch (error) {
      console.error('Login error:', error);
      toast({
        title: 'ত্রুটি',
        description: 'লগইনে সমস্যা হয়েছে',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSignup = async () => {
    if (!fullName.trim()) {
      toast({
        title: 'ত্রুটি',
        description: 'পুরো নাম লিখুন',
        variant: 'destructive',
      });
      return;
    }

    if (password.length < 6) {
      toast({
        title: 'ত্রুটি',
        description: 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);
    try {
      console.log('Starting signup process with data:', {
        email,
        fullName,
        phone,
        role
      });

      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: `${window.location.origin}/`,
          data: {
            full_name: fullName,
            phone: phone || null,
            role: role,
          }
        }
      });

      console.log('Signup response:', { data, error });

      if (error) {
        console.error('Signup error:', error);
        
        if (error.message.includes('User already registered')) {
          toast({
            title: 'ত্রুটি',
            description: 'এই ইমেইল দিয়ে ইতিমধ্যে একাউন্ট আছে',
            variant: 'destructive',
          });
        } else if (error.message.includes('Password should be at least 6 characters')) {
          toast({
            title: 'ত্রুটি',
            description: 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে',
            variant: 'destructive',
          });
        } else {
          toast({
            title: 'রেজিস্ট্রেশন ত্রুটি',
            description: error.message,
            variant: 'destructive',
          });
        }
      } else {
        console.log('Signup successful, user created:', data.user?.id);
        toast({
          title: 'সফল!',
          description: 'একাউন্ট তৈরি হয়েছে। এখন লগইন করুন।',
        });
        setIsLogin(true);
        setEmail('');
        setPassword('');
        setFullName('');
        setPhone('');
        setRole('staff');
      }
    } catch (error) {
      console.error('Unexpected signup error:', error);
      toast({
        title: 'ত্রুটি',
        description: 'রেজিস্ট্রেশনে সমস্যা হয়েছে',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isLogin) {
      handleLogin();
    } else {
      handleSignup();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <div className="w-12 h-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
              <Zap className="w-6 h-6 text-white" />
            </div>
          </div>
          <CardTitle className="text-2xl font-bold bangla-text">
            মেসার্স মুন্নী ইলেকট্রিক
          </CardTitle>
          <p className="text-gray-600 bangla-text">
            {isLogin ? 'আপনার একাউন্টে লগইন করুন' : 'নতুন একাউন্ট তৈরি করুন'}
          </p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {!isLogin && (
              <>
                <div className="space-y-2">
                  <Label htmlFor="fullName" className="bangla-text">পুরো নাম *</Label>
                  <Input
                    id="fullName"
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="আপনার পুরো নাম লিখুন"
                    required={!isLogin}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone" className="bangla-text">ফোন নম্বর (ঐচ্ছিক)</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="০১৭xxxxxxxx"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="role" className="bangla-text">ভূমিকা</Label>
                  <select
                    id="role"
                    value={role}
                    onChange={(e) => setRole(e.target.value as 'owner' | 'staff')}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="staff">কর্মচারী</option>
                    <option value="owner">মালিক</option>
                  </select>
                </div>
              </>
            )}
            
            <div className="space-y-2">
              <Label htmlFor="email" className="bangla-text">ইমেইল *</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="your@email.com"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="password" className="bangla-text">
                পাসওয়ার্ড * {!isLogin && <span className="text-sm text-gray-500">(কমপক্ষে ৬ অক্ষর)</span>}
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="পাসওয়ার্ড লিখুন"
                  required
                  minLength={6}
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="absolute right-0 top-0 h-full px-3 py-2 hover:bg-transparent"
                  onClick={() => setShowPassword(!showPassword)}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4 text-gray-500" />
                  ) : (
                    <Eye className="h-4 w-4 text-gray-500" />
                  )}
                </Button>
              </div>
            </div>

            <Button 
              type="submit" 
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 bangla-text"
              disabled={loading}
            >
              {loading ? 'অপেক্ষা করুন...' : isLogin ? 'লগইন' : 'রেজিস্টার'}
            </Button>
          </form>

          <div className="mt-4 text-center">
            <Button
              variant="link"
              onClick={() => {
                setIsLogin(!isLogin);
                setEmail('');
                setPassword('');
                setFullName('');
                setPhone('');
                setRole('staff');
              }}
              className="bangla-text"
            >
              {isLogin 
                ? 'নতুন একাউন্ট তৈরি করতে চান? রেজিস্টার করুন' 
                : 'ইতিমধ্যে একাউন্ট আছে? লগইন করুন'
              }
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Auth;
