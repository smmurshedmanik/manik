
import React from 'react';
import POSHeader from '@/components/POSHeader';
import DashboardStats from '@/components/DashboardStats';
import TimeBasedGreeting from '@/components/TimeBasedGreeting';
import SalesChart from '@/components/SalesChart';

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      <POSHeader />
      
      <main className="w-full px-2 sm:px-4 lg:px-6 py-4 sm:py-8">
        {/* Welcome Section with enhanced styling */}
        <div className="mb-6 sm:mb-8">
          <TimeBasedGreeting />
        </div>

        {/* Dashboard Stats with improved design */}
        <div className="mb-8">
          <DashboardStats />
        </div>
        
        {/* Combined Graphical Reports and Analytics Section with better styling */}
        <div className="mb-8">
          <SalesChart />
        </div>
        
        {/* Enhanced Footer */}
        <footer className="mt-8 sm:mt-12 text-center text-gray-600 bangla-text">
          <div className="border-t border-gray-200 pt-4 sm:pt-6 bg-gradient-to-r from-white/60 via-blue-50/60 to-purple-50/60 backdrop-blur-sm rounded-xl p-4 sm:p-6 mx-2 sm:mx-0 shadow-lg border border-blue-100">
            <p className="text-xs sm:text-sm font-medium text-gray-700">
              © ২০২৫ মেসার্স মুন্নী ইলেকট্রিক - সর্বস্বত্ব সংরক্ষিত
            </p>
            <p className="text-xs mt-2 text-gray-500">
              নতুন বাজার বড় মহেশখালী, মহেশখালী, কক্সবাজার
            </p>
            <p className="text-xs mt-1 text-gray-500">
              ফোন: +৮৮০১৮৩৪-৫৪৪১৭৫ | ইমেইল: info@munneeelectric.com
            </p>
          </div>
        </footer>
      </main>
    </div>
  );
};

export default Index;
