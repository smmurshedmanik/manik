
import React from 'react';
import POSHeader from '@/components/POSHeader';
import CustomerManager from '@/components/sales/CustomerManager';

const Customers = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      <POSHeader />
      
      <main className="w-full px-2 sm:px-4 lg:px-6 py-4 sm:py-8">
        <div className="mb-4 sm:mb-6">
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-800 bangla-text mb-2">
            গ্রাহক তালিকা
          </h1>
          <p className="text-sm sm:text-base text-gray-600 bangla-text">
            সকল গ্রাহকের তথ্য দেখুন এবং পরিচালনা করুন
          </p>
        </div>

        <CustomerManager />
      </main>
    </div>
  );
};

export default Customers;
