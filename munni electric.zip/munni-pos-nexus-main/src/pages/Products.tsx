
import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import POSHeader from '@/components/POSHeader';
import ProductList from '@/components/products/ProductList';
import AddProduct from '@/components/products/AddProduct';
import CategoryManager from '@/components/products/CategoryManager';
import BrandManager from '@/components/products/BrandManager';
import StockMovement from '@/components/products/StockMovement';
import StockAlerts from '@/components/products/StockAlerts';
import ProductLabeling from '@/components/products/ProductLabeling';

const Products = () => {
  const [activeTab, setActiveTab] = useState('products');
  const location = useLocation();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const tab = params.get('tab');
    
    if (tab && ['products', 'add-product', 'categories', 'brands', 'stock', 'alerts', 'labeling'].includes(tab)) {
      setActiveTab(tab);
    }
  }, [location]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      <POSHeader />
      
      <main className="w-full px-2 sm:px-4 lg:px-6 py-4 sm:py-8">
        <div className="mb-4 sm:mb-6">
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-800 bangla-text mb-2">
            পণ্য ব্যবস্থাপনা
          </h1>
          <p className="text-sm sm:text-base text-gray-600 bangla-text">
            পণ্য, ক্যাটাগরি, ব্র্যান্ড এবং স্টক পরিচালনা করুন
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 text-xs sm:text-sm">
            <TabsTrigger value="products" className="bangla-text">পণ্য তালিকা</TabsTrigger>
            <TabsTrigger value="add-product" className="bangla-text">নতুন পণ্য</TabsTrigger>
            <TabsTrigger value="categories" className="bangla-text">ক্যাটাগরি</TabsTrigger>
            <TabsTrigger value="brands" className="bangla-text">ব্র্যান্ড</TabsTrigger>
            <TabsTrigger value="stock" className="bangla-text">স্টক</TabsTrigger>
            <TabsTrigger value="alerts" className="bangla-text">সতর্কতা</TabsTrigger>
            <TabsTrigger value="labeling" className="bangla-text">পণ্য লেভেলিং</TabsTrigger>
          </TabsList>

          <TabsContent value="products" className="mt-6">
            <ProductList />
          </TabsContent>

          <TabsContent value="add-product" className="mt-6">
            <AddProduct onSuccess={() => setActiveTab('products')} />
          </TabsContent>

          <TabsContent value="categories" className="mt-6">
            <CategoryManager />
          </TabsContent>

          <TabsContent value="brands" className="mt-6">
            <BrandManager />
          </TabsContent>

          <TabsContent value="stock" className="mt-6">
            <StockMovement />
          </TabsContent>

          <TabsContent value="alerts" className="mt-6">
            <StockAlerts />
          </TabsContent>

          <TabsContent value="labeling" className="mt-6">
            <ProductLabeling />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Products;
