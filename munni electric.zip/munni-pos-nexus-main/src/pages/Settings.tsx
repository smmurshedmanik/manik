import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { 
  Settings as SettingsIcon, 
  Store, 
  Bell, 
  Shield, 
  Database, 
  Printer, 
  Users,
  Save,
  RefreshCw,
  Download,
  Upload
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import POSHeader from '@/components/POSHeader';
import UserManagement from '@/components/UserManagement';

const Settings = () => {
  const { toast } = useToast();
  const { userProfile, isOwner } = useAuth();
  const [loading, setLoading] = useState(false);

  // Store Settings State
  const [storeSettings, setStoreSettings] = useState({
    storeName: 'মেসার্স মুন্নী ইলেকট্রিক',
    address: 'নতুন বাজার বড় মহেশখালী, মহেশখালী, কক্সবাজার',
    phone: '+৮৮০১৮৩৪-৫৪৪১৭৫',
    email: 'info@munneeelectric.com',
    currency: 'BDT',
    taxRate: '15',
    lowStockThreshold: '10'
  });

  // Notification Settings State
  const [notifications, setNotifications] = useState({
    lowStock: true,
    dailySales: true,
    newCustomer: false,
    paymentReminder: true,
    emailNotifications: false,
    smsNotifications: true
  });

  // Print Settings State
  const [printSettings, setPrintSettings] = useState({
    printerName: 'Default',
    paperSize: 'A4',
    autoprint: false,
    includeBarcode: true,
    includeQR: false,
    copies: '1'
  });

  const handleSaveStoreSettings = async () => {
    setLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast({
        title: 'সফল!',
        description: 'দোকানের তথ্য আপডেট করা হয়েছে',
      });
    } catch (error) {
      toast({
        title: 'ত্রুটি',
        description: 'তথ্য আপডেট করতে সমস্যা হয়েছে',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleBackupData = async () => {
    setLoading(true);
    try {
      await new Promise(resolve => setTimeout(resolve, 2000));
      toast({
        title: 'সফল!',
        description: 'ডেটা ব্যাকআপ সম্পন্ন হয়েছে',
      });
    } catch (error) {
      toast({
        title: 'ত্রুটি',
        description: 'ব্যাকআপ করতে সমস্যা হয়েছে',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  if (!isOwner) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
        <POSHeader />
        <main className="w-full px-2 sm:px-4 lg:px-6 py-4 sm:py-8">
          <Card className="pos-card border-0 text-center shadow-xl">
            <CardContent className="p-8">
              <Shield className="w-16 h-16 text-red-500 mx-auto mb-4" />
              <h2 className="text-xl font-bold text-red-600 bangla-text mb-2">অ্যাক্সেস নিষেধ</h2>
              <p className="text-gray-600 bangla-text">সেটিংস পেজ শুধুমাত্র মালিকদের জন্য</p>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
      <POSHeader />
      
      <main className="w-full px-2 sm:px-4 lg:px-6 py-4 sm:py-8">
        <div className="mb-4 sm:mb-6">
          <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-800 bangla-text mb-2">
            সিস্টেম সেটিংস
          </h1>
          <p className="text-sm sm:text-base text-gray-600 bangla-text">
            সিস্টেমের কনফিগারেশন এবং পছন্দসমূহ পরিবর্তন করুন
          </p>
        </div>

        <Tabs defaultValue="store" className="w-full">
          <TabsList className="grid w-full grid-cols-5 bg-gradient-to-r from-blue-50 to-purple-50 shadow-xl rounded-xl border border-blue-100">
            <TabsTrigger value="store" className="bangla-text font-semibold transition-all duration-300 hover:scale-105 data-[state=active]:bg-gradient-to-r data-[state=active]:from-blue-600 data-[state=active]:to-purple-600 data-[state=active]:text-white">দোকানের তথ্য</TabsTrigger>
            <TabsTrigger value="notifications" className="bangla-text font-semibold transition-all duration-300 hover:scale-105 data-[state=active]:bg-gradient-to-r data-[state=active]:from-green-600 data-[state=active]:to-teal-600 data-[state=active]:text-white">নোটিফিকেশন</TabsTrigger>
            <TabsTrigger value="printing" className="bangla-text font-semibold transition-all duration-300 hover:scale-105 data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600 data-[state=active]:text-white">প্রিন্টিং</TabsTrigger>
            <TabsTrigger value="users" className="bangla-text font-semibold transition-all duration-300 hover:scale-105 data-[state=active]:bg-gradient-to-r data-[state=active]:from-indigo-600 data-[state=active]:to-purple-600 data-[state=active]:text-white">ব্যবহারকারী</TabsTrigger>
            <TabsTrigger value="backup" className="bangla-text font-semibold transition-all duration-300 hover:scale-105 data-[state=active]:bg-gradient-to-r data-[state=active]:from-orange-600 data-[state=active]:to-red-600 data-[state=active]:text-white">ব্যাকআপ</TabsTrigger>
          </TabsList>

          {/* Store Information Settings */}
          <TabsContent value="store" className="mt-6">
            <Card className="pos-card border-0 shadow-xl bg-gradient-to-br from-white to-blue-50/30">
              <CardHeader className="bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-t-lg">
                <CardTitle className="text-lg font-bold bangla-text flex items-center">
                  <Store className="w-5 h-5 mr-2" />
                  দোকানের তথ্য
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="storeName" className="bangla-text font-semibold">দোকানের নাম *</Label>
                    <Input
                      id="storeName"
                      value={storeSettings.storeName}
                      onChange={(e) => setStoreSettings({...storeSettings, storeName: e.target.value})}
                      className="bangla-text"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="phone" className="bangla-text font-semibold">ফোন নম্বর *</Label>
                    <Input
                      id="phone"
                      value={storeSettings.phone}
                      onChange={(e) => setStoreSettings({...storeSettings, phone: e.target.value})}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="address" className="bangla-text font-semibold">ঠিকানা *</Label>
                  <Textarea
                    id="address"
                    value={storeSettings.address}
                    onChange={(e) => setStoreSettings({...storeSettings, address: e.target.value})}
                    className="bangla-text"
                    rows={3}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="bangla-text font-semibold">ইমেইল</Label>
                    <Input
                      id="email"
                      type="email"
                      value={storeSettings.email}
                      onChange={(e) => setStoreSettings({...storeSettings, email: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label className="bangla-text font-semibold">মুদ্রা</Label>
                    <Select value={storeSettings.currency} onValueChange={(value) => setStoreSettings({...storeSettings, currency: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="BDT">বাংলাদেশী টাকা (৳)</SelectItem>
                        <SelectItem value="USD">ইউএস ডলার ($)</SelectItem>
                        <SelectItem value="EUR">ইউরো (€)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="taxRate" className="bangla-text font-semibold">ট্যাক্স রেট (%)</Label>
                    <Input
                      id="taxRate"
                      type="number"
                      value={storeSettings.taxRate}
                      onChange={(e) => setStoreSettings({...storeSettings, taxRate: e.target.value})}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="lowStock" className="bangla-text font-semibold">কম স্টক সীমা</Label>
                    <Input
                      id="lowStock"
                      type="number"
                      value={storeSettings.lowStockThreshold}
                      onChange={(e) => setStoreSettings({...storeSettings, lowStockThreshold: e.target.value})}
                    />
                  </div>
                </div>

                <Button onClick={handleSaveStoreSettings} disabled={loading} className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 bangla-text shadow-lg">
                  <Save className="w-4 h-4 mr-2" />
                  {loading ? 'সেভ করা হচ্ছে...' : 'পরিবর্তন সেভ করুন'}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Notification Settings */}
          <TabsContent value="notifications" className="mt-6">
            <Card className="pos-card border-0 shadow-xl bg-gradient-to-br from-white to-green-50/30">
              <CardHeader className="bg-gradient-to-r from-green-500 to-teal-600 text-white rounded-t-lg">
                <CardTitle className="text-lg font-bold bangla-text flex items-center">
                  <Bell className="w-5 h-5 mr-2" />
                  নোটিফিকেশন সেটিংস
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="space-y-4">
                  {[
                    { key: 'lowStock', label: 'কম স্টক সতর্কতা', desc: 'স্টক কম হলে নোটিফিকেশন পাবেন' },
                    { key: 'dailySales', label: 'দৈনিক বিক্রয় রিপোর্ট', desc: 'প্রতিদিন বিক্রয়ের সারসংক্ষেপ পাবেন' },
                    { key: 'newCustomer', label: 'নতুন গ্রাহক', desc: 'নতুন গ্রাহক যুক্ত হলে জানান দিবে' },
                    { key: 'paymentReminder', label: 'পেমেন্ট রিমাইন্ডার', desc: 'বকেয়া পেমেন্টের জন্য রিমাইন্ডার' }
                  ].map((item) => (
                    <div key={item.key} className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-green-50 rounded-xl border border-green-100">
                      <div>
                        <h3 className="font-semibold bangla-text">{item.label}</h3>
                        <p className="text-sm text-gray-600 bangla-text">{item.desc}</p>
                      </div>
                      <Switch
                        checked={notifications[item.key as keyof typeof notifications]}
                        onCheckedChange={(checked) => setNotifications({...notifications, [item.key]: checked})}
                      />
                    </div>
                  ))}
                </div>

                <div className="border-t pt-6 space-y-4">
                  <h3 className="font-semibold bangla-text">নোটিফিকেশনের মাধ্যম</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-center justify-between p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-100">
                      <div>
                        <h4 className="font-semibold bangla-text">ইমেইল নোটিফিকেশন</h4>
                        <p className="text-sm text-gray-600 bangla-text">ইমেইলে নোটিফিকেশন পাবেন</p>
                      </div>
                      <Switch
                        checked={notifications.emailNotifications}
                        onCheckedChange={(checked) => setNotifications({...notifications, emailNotifications: checked})}
                      />
                    </div>
                    <div className="flex items-center justify-between p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-100">
                      <div>
                        <h4 className="font-semibold bangla-text">SMS নোটিফিকেশন</h4>
                        <p className="text-sm text-gray-600 bangla-text">মোবাইলে SMS পাবেন</p>
                      </div>
                      <Switch
                        checked={notifications.smsNotifications}
                        onCheckedChange={(checked) => setNotifications({...notifications, smsNotifications: checked})}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Printing Settings */}
          <TabsContent value="printing" className="mt-6">
            <Card className="pos-card border-0 shadow-xl bg-gradient-to-br from-white to-purple-50/30">
              <CardHeader className="bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-t-lg">
                <CardTitle className="text-lg font-bold bangla-text flex items-center">
                  <Printer className="w-5 h-5 mr-2" />
                  প্রিন্টিং সেটিংস
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label className="bangla-text font-semibold">প্রিন্টার</Label>
                    <Select value={printSettings.printerName} onValueChange={(value) => setPrintSettings({...printSettings, printerName: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Default">ডিফল্ট প্রিন্টার</SelectItem>
                        <SelectItem value="Thermal">থার্মাল প্রিন্টার</SelectItem>
                        <SelectItem value="Inkjet">ইনকজেট প্রিন্টার</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="bangla-text font-semibold">কাগজের সাইজ</Label>
                    <Select value={printSettings.paperSize} onValueChange={(value) => setPrintSettings({...printSettings, paperSize: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="A4">A4 (210 x 297 mm)</SelectItem>
                        <SelectItem value="A5">A5 (148 x 210 mm)</SelectItem>
                        <SelectItem value="Thermal">থার্মাল (58/80 mm)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-purple-50 rounded-xl border border-purple-100">
                    <div>
                      <h3 className="font-semibold bangla-text">অটো প্রিন্ট</h3>
                      <p className="text-sm text-gray-600 bangla-text">বিক্রয়ের পর স্বয়ংক্রিয়ভাবে প্রিন্ট হবে</p>
                    </div>
                    <Switch
                      checked={printSettings.autoprint}
                      onCheckedChange={(checked) => setPrintSettings({...printSettings, autoprint: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-purple-50 rounded-xl border border-purple-100">
                    <div>
                      <h3 className="font-semibold bangla-text">বারকোড অন্তর্ভুক্ত করুন</h3>
                      <p className="text-sm text-gray-600 bangla-text">ইনভয়েসে বারকোড প্রিন্ট করুন</p>
                    </div>
                    <Switch
                      checked={printSettings.includeBarcode}
                      onCheckedChange={(checked) => setPrintSettings({...printSettings, includeBarcode: checked})}
                    />
                  </div>

                  <div className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-purple-50 rounded-xl border border-purple-100">
                    <div>
                      <h3 className="font-semibold bangla-text">QR কোড অন্তর্ভুক্ত করুন</h3>
                      <p className="text-sm text-gray-600 bangla-text">ইনভয়েসে QR কোড প্রিন্ট করুন</p>
                    </div>
                    <Switch
                      checked={printSettings.includeQR}
                      onCheckedChange={(checked) => setPrintSettings({...printSettings, includeQR: checked})}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="copies" className="bangla-text font-semibold">কপির সংখ্যা</Label>
                  <Input
                    id="copies"
                    type="number"
                    min="1"
                    max="5"
                    value={printSettings.copies}
                    onChange={(e) => setPrintSettings({...printSettings, copies: e.target.value})}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* User Management */}
          <TabsContent value="users" className="mt-6">
            <UserManagement />
          </TabsContent>

          {/* Backup & Data Management */}
          <TabsContent value="backup" className="mt-6">
            <Card className="pos-card border-0 shadow-xl bg-gradient-to-br from-white to-orange-50/30">
              <CardHeader className="bg-gradient-to-r from-orange-500 to-red-600 text-white rounded-t-lg">
                <CardTitle className="text-lg font-bold bangla-text flex items-center">
                  <Database className="w-5 h-5 mr-2" />
                  ডেটা ব্যাকআপ ও পুনরুদ্ধার
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <h3 className="font-semibold bangla-text text-lg">ডেটা ব্যাকআপ</h3>
                    <p className="text-sm text-gray-600 bangla-text">
                      আপনার সমস্ত বিক্রয়, পণ্য এবং গ্রাহকের তথ্য ব্যাকআপ করুন
                    </p>
                    <Button onClick={handleBackupData} disabled={loading} className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 bangla-text shadow-lg">
                      <Download className="w-4 h-4 mr-2" />
                      {loading ? 'ব্যাকআপ করা হচ্ছে...' : 'ডেটা ব্যাকআপ করুন'}
                    </Button>
                  </div>

                  <div className="space-y-4">
                    <h3 className="font-semibold bangla-text text-lg">ডেটা আমদানি</h3>
                    <p className="text-sm text-gray-600 bangla-text">
                      পূর্বের ব্যাকআপ ফাইল থেকে ডেটা পুনরুদ্ধার করুন
                    </p>
                    <Button variant="outline" className="w-full bangla-text border-orange-200 hover:bg-gradient-to-r hover:from-orange-50 hover:to-red-50">
                      <Upload className="w-4 h-4 mr-2" />
                      ব্যাকআপ ফাইল আপলোড করুন
                    </Button>
                  </div>
                </div>

                <div className="border-t pt-6">
                  <h3 className="font-semibold bangla-text text-lg mb-4">সিস্টেম তথ্য</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-4 rounded-xl text-center border border-blue-100">
                      <h4 className="font-semibold bangla-text">শেষ ব্যাকআপ</h4>
                      <p className="text-sm text-gray-600 bangla-text">আজ, ১২:৩০ PM</p>
                    </div>
                    <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-4 rounded-xl text-center border border-green-100">
                      <h4 className="font-semibold bangla-text">ডেটা সাইজ</h4>
                      <p className="text-sm text-gray-600 bangla-text">২৫.৮ MB</p>
                    </div>
                    <div className="bg-gradient-to-r from-purple-50 to-pink-50 p-4 rounded-xl text-center border border-purple-100">
                      <h4 className="font-semibold bangla-text">ভার্সন</h4>
                      <p className="text-sm text-gray-600 bangla-text">২.১.০</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export default Settings;
