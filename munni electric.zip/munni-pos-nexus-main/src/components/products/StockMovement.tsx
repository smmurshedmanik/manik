
import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { TrendingUp, TrendingDown, Package, Plus } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

interface Product {
  id: string;
  name: string;
  current_stock: number;
  unit: string;
}

interface StockMovement {
  id: string;
  movement_type: string;
  quantity: number;
  unit_price: number | null;
  total_price: number | null;
  reference_type: string | null;
  notes: string | null;
  created_at: string;
  products: { name: string; unit: string };
}

const StockMovement = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    product_id: '',
    movement_type: 'in',
    quantity: '',
    unit_price: '',
    reference_type: '',
    notes: '',
  });

  const { data: products } = useQuery({
    queryKey: ['products-for-stock'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('id, name, current_stock, unit')
        .eq('is_active', true)
        .order('name');
      if (error) throw error;
      return data as Product[];
    },
  });

  const { data: movements, refetch } = useQuery({
    queryKey: ['stock-movements'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('stock_movements')
        .select(`
          *,
          products (name, unit)
        `)
        .order('created_at', { ascending: false })
        .limit(10);
      if (error) throw error;
      return data as StockMovement[];
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const quantity = parseInt(formData.quantity);
      const unitPrice = formData.unit_price ? parseFloat(formData.unit_price) : null;
      const totalPrice = unitPrice ? unitPrice * quantity : null;

      const { error } = await supabase
        .from('stock_movements')
        .insert({
          product_id: formData.product_id,
          movement_type: formData.movement_type,
          quantity: quantity,
          unit_price: unitPrice,
          total_price: totalPrice,
          reference_type: formData.reference_type || null,
          notes: formData.notes || null,
        });

      if (error) throw error;

      toast({
        title: 'সফল!',
        description: 'স্টক আপডেট করা হয়েছে',
      });

      setFormData({
        product_id: '',
        movement_type: 'in',
        quantity: '',
        unit_price: '',
        reference_type: '',
        notes: '',
      });

      refetch();
    } catch (error) {
      toast({
        title: 'ত্রুটি',
        description: 'স্টক আপডেট করতে সমস্যা হয়েছে',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const selectedProduct = products?.find(p => p.id === formData.product_id);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Stock Movement Form */}
      <Card className="pos-card border-0">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-800 bangla-text flex items-center">
            <Plus className="w-5 h-5 mr-2" />
            স্টক আপডেট করুন
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label className="bangla-text">পণ্য নির্বাচন করুন *</Label>
              <Select value={formData.product_id} onValueChange={(value) => setFormData({ ...formData, product_id: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="পণ্য নির্বাচন করুন" />
                </SelectTrigger>
                <SelectContent>
                  {products?.map((product) => (
                    <SelectItem key={product.id} value={product.id}>
                      {product.name} (বর্তমান স্টক: {product.current_stock} {product.unit})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {selectedProduct && (
              <div className="p-3 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-800 bangla-text">
                  বর্তমান স্টক: <span className="font-bold">{selectedProduct.current_stock} {selectedProduct.unit}</span>
                </p>
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="bangla-text">মুভমেন্ট টাইপ *</Label>
                <Select value={formData.movement_type} onValueChange={(value) => setFormData({ ...formData, movement_type: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="in">স্টক ইন (In)</SelectItem>
                    <SelectItem value="out">স্টক আউট (Out)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="quantity" className="bangla-text">পরিমাণ *</Label>
                <Input
                  id="quantity"
                  type="number"
                  value={formData.quantity}
                  onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                  required
                  placeholder="পরিমাণ লিখুন"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="unit_price" className="bangla-text">একক মূল্য</Label>
                <Input
                  id="unit_price"
                  type="number"
                  step="0.01"
                  value={formData.unit_price}
                  onChange={(e) => setFormData({ ...formData, unit_price: e.target.value })}
                  placeholder="০.০০"
                />
              </div>

              <div className="space-y-2">
                <Label className="bangla-text">রেফারেন্স টাইপ</Label>
                <Select value={formData.reference_type} onValueChange={(value) => setFormData({ ...formData, reference_type: value })}>
                  <SelectTrigger>
                    <SelectValue placeholder="নির্বাচন করুন" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="purchase">ক্রয়</SelectItem>
                    <SelectItem value="sale">বিক্রয়</SelectItem>
                    <SelectItem value="adjustment">সমন্বয়</SelectItem>
                    <SelectItem value="return">ফেরত</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes" className="bangla-text">নোট</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                placeholder="অতিরিক্ত তথ্য লিখুন (ঐচ্ছিক)"
                className="bangla-text"
              />
            </div>

            <Button type="submit" disabled={loading || !formData.product_id} className="w-full bangla-text">
              {loading ? 'আপডেট করা হচ্ছে...' : 'স্টক আপডেট করুন'}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Recent Stock Movements */}
      <Card className="pos-card border-0">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-800 bangla-text flex items-center">
            <Package className="w-5 h-5 mr-2" />
            সাম্প্রতিক স্টক মুভমেন্ট
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {movements?.map((movement) => (
              <div key={movement.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    movement.movement_type === 'in' ? 'bg-green-100' : 'bg-red-100'
                  }`}>
                    {movement.movement_type === 'in' ? (
                      <TrendingUp className="w-4 h-4 text-green-600" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-600" />
                    )}
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 bangla-text">{movement.products.name}</h4>
                    <p className="text-sm text-gray-600">
                      {movement.movement_type === 'in' ? '+' : '-'}{movement.quantity} {movement.products.unit}
                    </p>
                    <p className="text-xs text-gray-500">
                      {format(new Date(movement.created_at), 'dd/MM/yyyy HH:mm')}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <Badge variant={movement.movement_type === 'in' ? 'default' : 'destructive'} className="bangla-text">
                    {movement.movement_type === 'in' ? 'স্টক ইন' : 'স্টক আউট'}
                  </Badge>
                  {movement.total_price && (
                    <p className="text-sm text-gray-600 mt-1 bangla-text">৳{movement.total_price}</p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default StockMovement;
