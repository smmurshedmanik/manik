
import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { TrendingUp, TrendingDown, Package } from 'lucide-react';

interface StockViewModalProps {
  productId: string;
  isOpen: boolean;
  onClose: () => void;
}

const StockViewModal = ({ productId, isOpen, onClose }: StockViewModalProps) => {
  // Function to convert English numbers to Bengali
  const toBengaliNumber = (num: number) => {
    const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return num.toString().replace(/\d/g, (digit) => bengaliDigits[parseInt(digit)]);
  };

  // Get product data
  const { data: product } = useQuery({
    queryKey: ['product', productId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('id', productId)
        .single();
      
      if (error) throw error;
      return data;
    },
    enabled: !!productId && isOpen
  });

  // Get stock movements
  const { data: movements = [] } = useQuery({
    queryKey: ['stock-movements', productId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('stock_movements')
        .select('*')
        .eq('product_id', productId)
        .order('created_at', { ascending: false })
        .limit(20);
      
      if (error) throw error;
      return data;
    },
    enabled: !!productId && isOpen
  });

  if (!product) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="bangla-text">স্টক বিস্তারিত - {product.name}</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          {/* Current Stock Info */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <div className="flex items-center">
                <Package className="w-8 h-8 text-green-600 mr-3" />
                <div>
                  <p className="text-sm text-gray-600 bangla-text">বর্তমান স্টক</p>
                  <p className="text-2xl font-bold text-green-600 bangla-text">
                    {toBengaliNumber(product.current_stock)} {product.unit}
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-orange-50 p-4 rounded-lg border border-orange-200">
              <div className="flex items-center">
                <TrendingDown className="w-8 h-8 text-orange-600 mr-3" />
                <div>
                  <p className="text-sm text-gray-600 bangla-text">মিনিমাম স্টক</p>
                  <p className="text-2xl font-bold text-orange-600 bangla-text">
                    {toBengaliNumber(product.min_stock)} {product.unit}
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
              <div className="flex items-center">
                <TrendingUp className="w-8 h-8 text-blue-600 mr-3" />
                <div>
                  <p className="text-sm text-gray-600 bangla-text">স্টক স্ট্যাটাস</p>
                  <Badge 
                    variant={product.current_stock > product.min_stock ? 'default' : 'destructive'}
                    className="text-lg px-3 py-1 bangla-text"
                  >
                    {product.current_stock > product.min_stock ? 'পর্যাপ্ত' : 'কম স্টক'}
                  </Badge>
                </div>
              </div>
            </div>
          </div>

          {/* Stock Movement History */}
          <div>
            <h3 className="text-lg font-bold text-gray-800 bangla-text mb-4">স্টক চলাচলের ইতিহাস</h3>
            
            {movements.length === 0 ? (
              <div className="text-center py-8">
                <p className="text-gray-500 bangla-text">কোনো স্টক চলাচল পাওয়া যায়নি</p>
              </div>
            ) : (
              <div className="space-y-3">
                {movements.map((movement) => (
                  <div key={movement.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border">
                    <div className="flex items-center space-x-4">
                      {movement.movement_type === 'in' ? (
                        <TrendingUp className="w-5 h-5 text-green-600" />
                      ) : (
                        <TrendingDown className="w-5 h-5 text-red-600" />
                      )}
                      <div>
                        <p className="font-semibold bangla-text">
                          {movement.movement_type === 'in' ? 'স্টক ইন' : 'স্টক আউট'}
                        </p>
                        <p className="text-sm text-gray-600 bangla-text">
                          পরিমাণ: {toBengaliNumber(movement.quantity)} {product.unit}
                        </p>
                        {movement.notes && (
                          <p className="text-xs text-gray-500 bangla-text">{movement.notes}</p>
                        )}
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <p className="text-sm text-gray-600">
                        {new Date(movement.created_at).toLocaleDateString('bn-BD')}
                      </p>
                      <p className="text-xs text-gray-500">
                        {new Date(movement.created_at).toLocaleTimeString('bn-BD')}
                      </p>
                      {movement.unit_price && (
                        <p className="text-sm font-semibold bangla-text">
                          ৳{toBengaliNumber(movement.unit_price)} প্রতি {product.unit}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default StockViewModal;
