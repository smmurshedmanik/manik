
import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit, Trash2, Award } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Brand {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
}

const BrandManager = () => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
  });

  const { data: brands, isLoading, refetch } = useQuery({
    queryKey: ['brands'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('brands')
        .select('*')
        .order('name');
      if (error) throw error;
      return data as Brand[];
    },
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const { error } = await supabase
        .from('brands')
        .insert({
          name: formData.name,
          description: formData.description || null,
        });

      if (error) throw error;

      toast({
        title: 'সফল!',
        description: 'নতুন ব্র্যান্ড যোগ করা হয়েছে',
      });

      setFormData({ name: '', description: '' });
      refetch();
    } catch (error) {
      toast({
        title: 'ত্রুটি',
        description: 'ব্র্যান্ড যোগ করতে সমস্যা হয়েছে',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const deleteBrand = async (id: string) => {
    try {
      const { error } = await supabase
        .from('brands')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: 'সফল!',
        description: 'ব্র্যান্ড মুছে ফেলা হয়েছে',
      });
      refetch();
    } catch (error) {
      toast({
        title: 'ত্রুটি',
        description: 'ব্র্যান্ড মুছতে সমস্যা হয়েছে',
        variant: 'destructive',
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Add Brand Form */}
      <Card className="pos-card border-0">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-800 bangla-text flex items-center">
            <Plus className="w-5 h-5 mr-2" />
            নতুন ব্র্যান্ড যোগ করুন
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="brand_name" className="bangla-text">ব্র্যান্ডের নাম *</Label>
              <Input
                id="brand_name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="bangla-text"
                placeholder="ব্র্যান্ডের নাম লিখুন"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="brand_description" className="bangla-text">বিবরণ</Label>
              <Input
                id="brand_description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="bangla-text"
                placeholder="বিবরণ লিখুন (ঐচ্ছিক)"
              />
            </div>

            <Button type="submit" disabled={loading} className="w-full bangla-text">
              {loading ? 'যোগ করা হচ্ছে...' : 'ব্র্যান্ড যোগ করুন'}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Brands List */}
      <Card className="pos-card border-0">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-800 bangla-text flex items-center justify-between">
            <div className="flex items-center">
              <Award className="w-5 h-5 mr-2" />
              ব্র্যান্ড তালিকা
            </div>
            <Badge variant="secondary" className="bangla-text">
              {brands?.length || 0} টি ব্র্যান্ড
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {brands?.map((brand) => (
              <div key={brand.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <h4 className="font-semibold text-gray-800 bangla-text">{brand.name}</h4>
                  {brand.description && (
                    <p className="text-sm text-gray-600 bangla-text">{brand.description}</p>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <Button size="sm" variant="outline">
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button 
                    size="sm" 
                    variant="destructive"
                    onClick={() => deleteBrand(brand.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default BrandManager;
