
import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, Package, Check, X } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { format } from 'date-fns';

interface StockAlert {
  id: string;
  alert_type: string;
  is_read: boolean;
  created_at: string;
  products: {
    id: string;
    name: string;
    current_stock: number;
    min_stock: number;
    unit: string;
  };
}

const StockAlerts = () => {
  const { toast } = useToast();

  const { data: alerts, isLoading, refetch } = useQuery({
    queryKey: ['stock-alerts'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('stock_alerts')
        .select(`
          *,
          products (id, name, current_stock, min_stock, unit)
        `)
        .order('created_at', { ascending: false });
      if (error) throw error;
      return data as StockAlert[];
    },
  });

  const markAsRead = async (alertId: string) => {
    try {
      const { error } = await supabase
        .from('stock_alerts')
        .update({ is_read: true })
        .eq('id', alertId);

      if (error) throw error;

      toast({
        title: 'সফল!',
        description: 'সতর্কতা পড়া হয়েছে বলে চিহ্নিত করা হয়েছে',
      });
      refetch();
    } catch (error) {
      toast({
        title: 'ত্রুটি',
        description: 'সতর্কতা আপডেট করতে সমস্যা হয়েছে',
        variant: 'destructive',
      });
    }
  };

  const deleteAlert = async (alertId: string) => {
    try {
      const { error } = await supabase
        .from('stock_alerts')
        .delete()
        .eq('id', alertId);

      if (error) throw error;

      toast({
        title: 'সফল!',
        description: 'সতর্কতা মুছে ফেলা হয়েছে',
      });
      refetch();
    } catch (error) {
      toast({
        title: 'ত্রুটি',
        description: 'সতর্কতা মুছতে সমস্যা হয়েছে',
        variant: 'destructive',
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  const unreadAlerts = alerts?.filter(alert => !alert.is_read) || [];
  const readAlerts = alerts?.filter(alert => alert.is_read) || [];

  return (
    <div className="space-y-6">
      {/* Unread Alerts */}
      <Card className="pos-card border-0">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-800 bangla-text flex items-center justify-between">
            <div className="flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2 text-red-500" />
              নতুন সতর্কতা
            </div>
            <Badge variant="destructive" className="bangla-text">
              {unreadAlerts.length} টি নতুন
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {unreadAlerts.length === 0 ? (
            <div className="text-center py-8">
              <Package className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 bangla-text">কোন নতুন সতর্কতা নেই</p>
            </div>
          ) : (
            <div className="space-y-3">
              {unreadAlerts.map((alert) => (
                <div key={alert.id} className="flex items-center justify-between p-4 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                      <Package className="w-5 h-5 text-red-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800 bangla-text">{alert.products.name}</h4>
                      <p className="text-sm text-gray-600 bangla-text">
                        বর্তমান স্টক: {alert.products.current_stock} {alert.products.unit}
                        {alert.alert_type === 'low_stock' && ` (সর্বনিম্ন: ${alert.products.min_stock})`}
                      </p>
                      <p className="text-xs text-gray-500">
                        {format(new Date(alert.created_at), 'dd/MM/yyyy HH:mm')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant="destructive" className="bangla-text">
                      {alert.alert_type === 'low_stock' ? 'কম স্টক' : 'স্টক শেষ'}
                    </Badge>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => markAsRead(alert.id)}
                    >
                      <Check className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => deleteAlert(alert.id)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Read Alerts */}
      {readAlerts.length > 0 && (
        <Card className="pos-card border-0">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-gray-800 bangla-text flex items-center justify-between">
              <div className="flex items-center">
                <Check className="w-5 h-5 mr-2 text-green-500" />
                পড়া সতর্কতা
              </div>
              <Badge variant="secondary" className="bangla-text">
                {readAlerts.length} টি পড়া
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 max-h-96 overflow-y-auto">
              {readAlerts.map((alert) => (
                <div key={alert.id} className="flex items-center justify-between p-4 bg-gray-50 border border-gray-200 rounded-lg opacity-75">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center">
                      <Package className="w-5 h-5 text-gray-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800 bangla-text">{alert.products.name}</h4>
                      <p className="text-sm text-gray-600 bangla-text">
                        বর্তমান স্টক: {alert.products.current_stock} {alert.products.unit}
                      </p>
                      <p className="text-xs text-gray-500">
                        {format(new Date(alert.created_at), 'dd/MM/yyyy HH:mm')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Badge variant="secondary" className="bangla-text">
                      {alert.alert_type === 'low_stock' ? 'কম স্টক' : 'স্টক শেষ'}
                    </Badge>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => deleteAlert(alert.id)}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default StockAlerts;
