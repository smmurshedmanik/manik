
import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Plus } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface AddProductProps {
  onSuccess: () => void;
}

interface Category {
  id: string;
  name: string;
}

interface Brand {
  id: string;
  name: string;
}

const AddProduct = ({ onSuccess }: AddProductProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    category_id: '',
    brand_id: '',
    purchase_price: '',
    retail_price: '',
    wholesale_price: '',
    current_stock: '',
    min_stock: '10',
    unit: 'পিস',
    barcode: '',
    is_active: true,
  });
  const [newCategory, setNewCategory] = useState('');
  const [newBrand, setNewBrand] = useState('');

  const { data: categories } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('categories')
        .select('id, name')
        .order('name');
      if (error) throw error;
      return data as Category[];
    },
  });

  const { data: brands } = useQuery({
    queryKey: ['brands'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('brands')
        .select('id, name')
        .order('name');
      if (error) throw error;
      return data as Brand[];
    },
  });

  const addNewCategory = async (categoryName: string) => {
    try {
      const { data, error } = await supabase
        .from('categories')
        .insert({ name: categoryName.trim() })
        .select()
        .single();

      if (error) throw error;

      // Refresh categories list
      queryClient.invalidateQueries({ queryKey: ['categories'] });
      
      return data.id;
    } catch (error) {
      console.error('Error adding category:', error);
      return null;
    }
  };

  const addNewBrand = async (brandName: string) => {
    try {
      const { data, error } = await supabase
        .from('brands')
        .insert({ name: brandName.trim() })
        .select()
        .single();

      if (error) throw error;

      // Refresh brands list
      queryClient.invalidateQueries({ queryKey: ['brands'] });
      
      return data.id;
    } catch (error) {
      console.error('Error adding brand:', error);
      return null;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      let categoryId = formData.category_id;
      let brandId = formData.brand_id;

      // Add new category if specified
      if (newCategory.trim() && !categoryId) {
        const newCategoryId = await addNewCategory(newCategory);
        if (newCategoryId) {
          categoryId = newCategoryId;
        }
      }

      // Add new brand if specified  
      if (newBrand.trim() && !brandId) {
        const newBrandId = await addNewBrand(newBrand);
        if (newBrandId) {
          brandId = newBrandId;
        }
      }

      const { error } = await supabase
        .from('products')
        .insert({
          name: formData.name,
          category_id: categoryId || null,
          brand_id: brandId || null,
          purchase_price: parseFloat(formData.purchase_price),
          retail_price: parseFloat(formData.retail_price),
          wholesale_price: parseFloat(formData.wholesale_price),
          current_stock: parseInt(formData.current_stock) || 0,
          min_stock: parseInt(formData.min_stock) || 10,
          unit: formData.unit,
          barcode: formData.barcode || null,
          is_active: formData.is_active,
        });

      if (error) throw error;

      toast({
        title: 'সফল!',
        description: 'নতুন পণ্য যোগ করা হয়েছে',
      });

      // Reset form
      setFormData({
        name: '',
        category_id: '',
        brand_id: '',
        purchase_price: '',
        retail_price: '',
        wholesale_price: '',
        current_stock: '',
        min_stock: '10',
        unit: 'পিস',
        barcode: '',
        is_active: true,
      });
      setNewCategory('');
      setNewBrand('');

      onSuccess();
    } catch (error) {
      toast({
        title: 'ত্রুটি',
        description: 'পণ্য যোগ করতে সমস্যা হয়েছে',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="pos-card border-0 max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-xl font-bold text-gray-800 bangla-text flex items-center">
          <Plus className="w-5 h-5 mr-2" />
          নতুন পণ্য যোগ করুন
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="bangla-text">পণ্যের নাম *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
                className="bangla-text"
                placeholder="পণ্যের নাম লিখুন"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="barcode" className="bangla-text">বারকোড</Label>
              <Input
                id="barcode"
                value={formData.barcode}
                onChange={(e) => setFormData({ ...formData, barcode: e.target.value })}
                placeholder="বারকোড (ঐচ্ছিক)"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="bangla-text">ক্যাটাগরি</Label>
              <Select value={formData.category_id} onValueChange={(value) => setFormData({ ...formData, category_id: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="ক্যাটাগরি নির্বাচন করুন" />
                </SelectTrigger>
                <SelectContent>
                  {categories?.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                placeholder="নতুন ক্যাটাগরি যোগ করুন"
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                className="bangla-text text-sm"
              />
            </div>

            <div className="space-y-2">
              <Label className="bangla-text">ব্র্যান্ড</Label>
              <Select value={formData.brand_id} onValueChange={(value) => setFormData({ ...formData, brand_id: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="ব্র্যান্ড নির্বাচন করুন" />
                </SelectTrigger>
                <SelectContent>
                  {brands?.map((brand) => (
                    <SelectItem key={brand.id} value={brand.id}>
                      {brand.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                placeholder="নতুন ব্র্যান্ড যোগ করুন"
                value={newBrand}
                onChange={(e) => setNewBrand(e.target.value)}
                className="bangla-text text-sm"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="purchase_price" className="bangla-text">ক্রয় মূল্য *</Label>
              <Input
                id="purchase_price"
                type="number"
                step="0.01"
                value={formData.purchase_price}
                onChange={(e) => setFormData({ ...formData, purchase_price: e.target.value })}
                required
                placeholder="০.০০"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="retail_price" className="bangla-text">খুচরা মূল্য *</Label>
              <Input
                id="retail_price"
                type="number"
                step="0.01"
                value={formData.retail_price}
                onChange={(e) => setFormData({ ...formData, retail_price: e.target.value })}
                required
                placeholder="০.০০"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="wholesale_price" className="bangla-text">পাইকারি মূল্য *</Label>
              <Input
                id="wholesale_price"
                type="number"
                step="0.01"
                value={formData.wholesale_price}
                onChange={(e) => setFormData({ ...formData, wholesale_price: e.target.value })}
                required
                placeholder="০.০০"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="current_stock" className="bangla-text">বর্তমান স্টক</Label>
              <Input
                id="current_stock"
                type="number"
                value={formData.current_stock}
                onChange={(e) => setFormData({ ...formData, current_stock: e.target.value })}
                placeholder="০"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="min_stock" className="bangla-text">সর্বনিম্ন স্টক</Label>
              <Input
                id="min_stock"
                type="number"
                value={formData.min_stock}
                onChange={(e) => setFormData({ ...formData, min_stock: e.target.value })}
                placeholder="১০"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="unit" className="bangla-text">একক</Label>
              <Select value={formData.unit} onValueChange={(value) => setFormData({ ...formData, unit: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="পিস">পিস</SelectItem>
                  <SelectItem value="কেজি">কেজি</SelectItem>
                  <SelectItem value="লিটার">লিটার</SelectItem>
                  <SelectItem value="মিটার">মিটার</SelectItem>
                  <SelectItem value="বস্তা">বস্তা</SelectItem>
                  <SelectItem value="ডজন">ডজন</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="is_active"
              checked={formData.is_active}
              onCheckedChange={(checked) => setFormData({ ...formData, is_active: checked })}
            />
            <Label htmlFor="is_active" className="bangla-text">পণ্য সক্রিয় রাখুন</Label>
          </div>

          <Button type="submit" disabled={loading} className="w-full bangla-text">
            {loading ? 'যোগ করা হচ্ছে...' : 'পণ্য যোগ করুন'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default AddProduct;
