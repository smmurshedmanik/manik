
import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Package, Edit, Trash2, BarChart3 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import ProductEditModal from './ProductEditModal';
import StockViewModal from './StockViewModal';

interface Product {
  id: string;
  name: string;
  purchase_price: number;
  retail_price: number;
  wholesale_price: number;
  current_stock: number;
  min_stock: number;
  unit: string;
  is_active: boolean;
  categories: { name: string } | null;
  brands: { name: string } | null;
}

const ProductList = () => {
  const { toast } = useToast();
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [viewingStockProductId, setViewingStockProductId] = useState<string | null>(null);

  const { data: products, isLoading, refetch } = useQuery({
    queryKey: ['products'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select(`
          *,
          categories (name),
          brands (name)
        `)
        .order('name');

      if (error) throw error;
      return data as Product[];
    },
  });

  const deleteProduct = async (id: string) => {
    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', id);

      if (error) throw error;

      toast({
        title: 'সফল!',
        description: 'পণ্য মুছে ফেলা হয়েছে',
      });
      refetch();
    } catch (error) {
      toast({
        title: 'ত্রুটি',
        description: 'পণ্য মুছতে সমস্যা হয়েছে',
        variant: 'destructive',
      });
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {products?.map((product) => (
          <Card key={product.id} className="pos-card border-0">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg font-bold bangla-text flex items-center">
                  <Package className="w-5 h-5 mr-2 text-blue-600" />
                  {product.name}
                </CardTitle>
                <Badge variant={product.is_active ? 'default' : 'secondary'}>
                  {product.is_active ? 'সক্রিয়' : 'নিষ্ক্রিয়'}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <span className="text-gray-600 bangla-text">ক্যাটাগরি:</span>
                  <p className="font-medium bangla-text">{product.categories?.name || 'N/A'}</p>
                </div>
                <div>
                  <span className="text-gray-600 bangla-text">ব্র্যান্ড:</span>
                  <p className="font-medium bangla-text">{product.brands?.name || 'N/A'}</p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 text-sm">
                <div>
                  <span className="text-gray-600 bangla-text">ক্রয়:</span>
                  <p className="font-medium bangla-text">৳{product.purchase_price}</p>
                </div>
                <div>
                  <span className="text-gray-600 bangla-text">খুচরা:</span>
                  <p className="font-medium bangla-text">৳{product.retail_price}</p>
                </div>
                <div>
                  <span className="text-gray-600 bangla-text">পাইকারি:</span>
                  <p className="font-medium bangla-text">৳{product.wholesale_price}</p>
                </div>
              </div>

              <div className="flex items-center justify-between p-2 bg-gray-50 rounded">
                <div className="text-sm">
                  <span className="text-gray-600 bangla-text">স্টক:</span>
                  <span className={`ml-1 font-bold bangla-text ${
                    product.current_stock <= product.min_stock ? 'text-red-600' : 'text-green-600'
                  }`}>
                    {product.current_stock} {product.unit}
                  </span>
                </div>
                {product.current_stock <= product.min_stock && (
                  <Badge variant="destructive" className="bangla-text">
                    কম স্টক
                  </Badge>
                )}
              </div>

              <div className="flex items-center gap-2 pt-2">
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="flex-1 bangla-text"
                  onClick={() => setEditingProductId(product.id)}
                >
                  <Edit className="w-4 h-4 mr-1" />
                  সম্পাদনা
                </Button>
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="flex-1 bangla-text"
                  onClick={() => setViewingStockProductId(product.id)}
                >
                  <BarChart3 className="w-4 h-4 mr-1" />
                  স্টক
                </Button>
                <Button 
                  size="sm" 
                  variant="destructive" 
                  onClick={() => deleteProduct(product.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Edit Modal */}
      {editingProductId && (
        <ProductEditModal
          productId={editingProductId}
          isOpen={!!editingProductId}
          onClose={() => setEditingProductId(null)}
        />
      )}

      {/* Stock View Modal */}
      {viewingStockProductId && (
        <StockViewModal
          productId={viewingStockProductId}
          isOpen={!!viewingStockProductId}
          onClose={() => setViewingStockProductId(null)}
        />
      )}
    </>
  );
};

export default ProductList;
