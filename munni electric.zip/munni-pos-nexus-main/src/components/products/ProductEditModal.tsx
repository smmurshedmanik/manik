
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface ProductEditModalProps {
  productId: string;
  isOpen: boolean;
  onClose: () => void;
}

const ProductEditModal = ({ productId, isOpen, onClose }: ProductEditModalProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [formData, setFormData] = useState({
    name: '',
    purchase_price: 0,
    retail_price: 0,
    wholesale_price: 0,
    current_stock: 0,
    min_stock: 0,
    unit: '',
    category_id: '',
    brand_id: '',
    is_active: true
  });

  // Get product data
  const { data: product } = useQuery({
    queryKey: ['product', productId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('id', productId)
        .single();
      
      if (error) throw error;
      return data;
    },
    enabled: !!productId && isOpen
  });

  // Get categories and brands
  const { data: categories = [] } = useQuery({
    queryKey: ['categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('categories')
        .select('*')
        .order('name');
      
      if (error) throw error;
      return data;
    }
  });

  const { data: brands = [] } = useQuery({
    queryKey: ['brands'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('brands')
        .select('*')
        .order('name');
      
      if (error) throw error;
      return data;
    }
  });

  React.useEffect(() => {
    if (product) {
      setFormData({
        name: product.name,
        purchase_price: product.purchase_price,
        retail_price: product.retail_price,
        wholesale_price: product.wholesale_price,
        current_stock: product.current_stock,
        min_stock: product.min_stock,
        unit: product.unit,
        category_id: product.category_id || '',
        brand_id: product.brand_id || '',
        is_active: product.is_active
      });
    }
  }, [product]);

  const updateMutation = useMutation({
    mutationFn: async (data: any) => {
      const { error } = await supabase
        .from('products')
        .update(data)
        .eq('id', productId);
      
      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: 'সফল!',
        description: 'পণ্য আপডেট করা হয়েছে',
      });
      queryClient.invalidateQueries({ queryKey: ['products'] });
      onClose();
    },
    onError: () => {
      toast({
        title: 'ত্রুটি!',
        description: 'পণ্য আপডেটে সমস্যা হয়েছে',
        variant: 'destructive',
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateMutation.mutate(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="bangla-text">পণ্য সম্পাদনা</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="bangla-text">পণ্যের নাম</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>
            
            <div>
              <Label className="bangla-text">একক</Label>
              <Input
                value={formData.unit}
                onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
              />
            </div>
            
            <div>
              <Label className="bangla-text">ক্রয় মূল্য</Label>
              <Input
                type="number"
                value={formData.purchase_price}
                onChange={(e) => setFormData({ ...formData, purchase_price: Number(e.target.value) })}
                required
              />
            </div>
            
            <div>
              <Label className="bangla-text">খুচরা মূল্য</Label>
              <Input
                type="number"
                value={formData.retail_price}
                onChange={(e) => setFormData({ ...formData, retail_price: Number(e.target.value) })}
                required
              />
            </div>
            
            <div>
              <Label className="bangla-text">পাইকারি মূল্য</Label>
              <Input
                type="number"
                value={formData.wholesale_price}
                onChange={(e) => setFormData({ ...formData, wholesale_price: Number(e.target.value) })}
                required
              />
            </div>
            
            <div>
              <Label className="bangla-text">বর্তমান স্টক</Label>
              <Input
                type="number"
                value={formData.current_stock}
                onChange={(e) => setFormData({ ...formData, current_stock: Number(e.target.value) })}
                required
              />
            </div>
            
            <div>
              <Label className="bangla-text">মিনিমাম স্টক</Label>
              <Input
                type="number"
                value={formData.min_stock}
                onChange={(e) => setFormData({ ...formData, min_stock: Number(e.target.value) })}
                required
              />
            </div>
            
            <div>
              <Label className="bangla-text">ক্যাটাগরি</Label>
              <Select value={formData.category_id} onValueChange={(value) => setFormData({ ...formData, category_id: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="ক্যাটাগরি নির্বাচন করুন" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label className="bangla-text">ব্র্যান্ড</Label>
              <Select value={formData.brand_id} onValueChange={(value) => setFormData({ ...formData, brand_id: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="ব্র্যান্ড নির্বাচন করুন" />
                </SelectTrigger>
                <SelectContent>
                  {brands.map((brand) => (
                    <SelectItem key={brand.id} value={brand.id}>
                      {brand.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex justify-end space-x-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="bangla-text">
              বাতিল
            </Button>
            <Button type="submit" disabled={updateMutation.isPending} className="bangla-text">
              {updateMutation.isPending ? 'আপডেট হচ্ছে...' : 'আপডেট করুন'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ProductEditModal;
