import React, { useState, useRef } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, Package, Printer, QrCode } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import Barcode from 'react-barcode';

interface Product {
  id: string;
  name: string;
  retail_price: number;
  wholesale_price: number;
  current_stock: number;
  unit: string;
  barcode: string;
  categories: { name: string } | null;
  brands: { name: string } | null;
}

const ProductLabeling = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedProducts, setSelectedProducts] = useState<Product[]>([]);
  const printRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const { data: products = [], isLoading } = useQuery({
    queryKey: ['products-labeling', searchTerm],
    queryFn: async () => {
      const query = supabase
        .from('products')
        .select(`
          id,
          name,
          retail_price,
          wholesale_price,
          current_stock,
          unit,
          barcode,
          categories (name),
          brands (name)
        `)
        .eq('is_active', true);

      if (searchTerm.trim()) {
        query.or(`name.ilike.%${searchTerm}%,barcode.ilike.%${searchTerm}%`);
      }

      const { data, error } = await query.limit(20);
      if (error) throw error;
      return data as Product[];
    },
  });

  const generateBarcode = (product: Product) => {
    // Generate barcode if not exists
    if (!product.barcode) {
      const generatedBarcode = `4${product.id.replace(/-/g, '').substring(0, 11)}`;
      return generatedBarcode;
    }
    return product.barcode;
  };

  const addToSelection = (product: Product) => {
    if (!selectedProducts.find(p => p.id === product.id)) {
      setSelectedProducts([...selectedProducts, product]);
      toast({
        title: "পণ্য যোগ করা হয়েছে! ✅",
        description: `${product.name} লেভেল প্রিন্টের জন্য নির্বাচিত হয়েছে`,
      });
    }
  };

  const removeFromSelection = (productId: string) => {
    setSelectedProducts(selectedProducts.filter(p => p.id !== productId));
  };

  const handlePrint = () => {
    if (selectedProducts.length === 0) {
      toast({
        title: "ত্রুটি!",
        description: "প্রিন্টের জন্য অন্তত একটি পণ্য নির্বাচন করুন।",
        variant: "destructive",
      });
      return;
    }

    const printWindow = window.open('', '_blank');
    const printContent = printRef.current?.innerHTML;
    
    if (printWindow && printContent) {
      printWindow.document.write(`
        <html>
          <head>
            <title>পণ্য লেভেল প্রিন্ট</title>
            <style>
              @page { 
                size: A4; 
                margin: 15mm; 
              }
              body { 
                font-family: Arial, sans-serif; 
                margin: 0; 
                padding: 0;
                background: white;
              }
              .label-grid { 
                display: grid; 
                grid-template-columns: repeat(3, 1fr); 
                gap: 12px; 
                width: 100%;
              }
              .product-label { 
                border: 2px solid #333; 
                padding: 4px; 
                text-align: center; 
                page-break-inside: avoid;
                background: white;
                width: 1in;
                height: 1in;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
              }
              .product-header { 
                font-weight: bold; 
                font-size: 9px; 
                line-height: 1.1;
                margin-bottom: 2px;
                max-height: 18px;
                overflow: hidden;
                text-overflow: ellipsis;
                white-space: nowrap;
                width: 100%;
              }
              .barcode-container { 
                display: flex;
                align-items: center;
                justify-content: center;
                flex-grow: 1;
              }
              @media print {
                .no-print { display: none; }
                body { 
                  margin: 0; 
                  -webkit-print-color-adjust: exact;
                  print-color-adjust: exact;
                }
              }
            </style>
          </head>
          <body>
            ${printContent}
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }

    toast({
      title: "প্রিন্ট সফল! 🖨️",
      description: `${selectedProducts.length}টি পণ্যের লেভেল প্রিন্ট করা হচ্ছে`,
    });
  };

  return (
    <div className="space-y-6">
      {/* Search and Controls */}
      <Card className="pos-card border-0">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-800 bangla-text flex items-center">
            <QrCode className="w-5 h-5 mr-2" />
            পণ্য লেভেলিং ও বারকোড জেনারেশন
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-4 mb-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="পণ্য খুঁজুন (নাম বা বারকোড)"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bangla-text"
              />
            </div>
            <Button
              onClick={handlePrint}
              disabled={selectedProducts.length === 0}
              className="bangla-text bg-blue-600 hover:bg-blue-700"
            >
              <Printer className="w-4 h-4 mr-2" />
              প্রিন্ট করুন ({selectedProducts.length})
            </Button>
          </div>

          {selectedProducts.length > 0 && (
            <div className="mb-4 p-3 bg-blue-50 rounded-lg">
              <p className="text-sm text-blue-700 bangla-text mb-2">
                নির্বাচিত পণ্য: {selectedProducts.length}টি
              </p>
              <div className="flex flex-wrap gap-2">
                {selectedProducts.map(product => (
                  <Badge 
                    key={product.id} 
                    variant="secondary" 
                    className="cursor-pointer bangla-text"
                    onClick={() => removeFromSelection(product.id)}
                  >
                    {product.name} ✕
                  </Badge>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Product List */}
      <Card className="pos-card border-0">
        <CardHeader>
          <CardTitle className="bangla-text">পণ্য তালিকা</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {products.map((product) => (
                <div
                  key={product.id}
                  className="border rounded-lg p-4 hover:bg-gray-50 cursor-pointer"
                  onClick={() => addToSelection(product)}
                >
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold bangla-text text-sm">{product.name}</h4>
                    <Package className="w-4 h-4 text-blue-600" />
                  </div>
                  <div className="text-xs text-gray-600 bangla-text mb-2">
                    খুচরা: ৳{product.retail_price} | স্টক: {product.current_stock} {product.unit}
                  </div>
                  <div className="text-xs text-gray-500 bangla-text">
                    বারকোড: {generateBarcode(product)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Print Preview (Hidden) */}
      <div ref={printRef} className="hidden">
        <div className="label-grid">
          {selectedProducts.map((product) => (
            <div key={product.id} className="product-label">
              <div className="product-header">
                {product.name}
              </div>
              <div className="barcode-container">
                <Barcode 
                  value={generateBarcode(product)}
                  width={0.8}
                  height={25}
                  fontSize={8}
                  background="#ffffff"
                  lineColor="#000000"
                  margin={0}
                />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProductLabeling;
