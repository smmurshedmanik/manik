
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Calendar } from '@/components/ui/calendar';
import { CalendarIcon } from 'lucide-react';

const BengaliCalendar = () => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());

  const formatBengaliNumber = (num: number): string => {
    const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return num.toString().split('').map(digit => bengaliDigits[parseInt(digit)]).join('');
  };

  const getBengaliDate = (date: Date | undefined): string => {
    if (!date) return '';
    const months = [
      'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
      'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
    ];
    const day = formatBengaliNumber(date.getDate());
    const month = months[date.getMonth()];
    const year = formatBengaliNumber(date.getFullYear());
    return `${day} ${month}, ${year}`;
  };

  return (
    <Card className="modern-card h-full">
      <CardHeader className="pb-4">
        <CardTitle className="text-xl font-bold text-gray-800 bangla-text flex items-center gap-2">
          <CalendarIcon className="w-6 h-6 text-green-600" />
          ক্যালেন্ডার
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex justify-center">
          <Calendar
            mode="single"
            selected={selectedDate}
            onSelect={setSelectedDate}
            className="rounded-md border bg-white shadow-sm pointer-events-auto"
          />
        </div>
        {selectedDate && (
          <div className="text-center pt-4 border-t border-gray-200">
            <p className="text-sm text-gray-600 bangla-text mb-1">
              নির্বাচিত তারিখ:
            </p>
            <p className="text-lg font-medium text-green-600 bangla-text">
              {getBengaliDate(selectedDate)}
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default BengaliCalendar;
