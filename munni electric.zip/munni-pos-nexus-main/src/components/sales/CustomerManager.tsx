
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Users, Plus, Search, Edit, Phone, MapPin } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Customer {
  id: string;
  name: string;
  phone: string;
  address: string;
  current_balance: number;
  created_at: string;
}

const CustomerManager = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [customerForm, setCustomerForm] = useState({
    name: '',
    phone: '',
    address: ''
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: customers = [], isLoading } = useQuery({
    queryKey: ['customers', searchTerm],
    queryFn: async () => {
      let query = supabase
        .from('customers')
        .select('*')
        .order('created_at', { ascending: false });

      if (searchTerm.trim()) {
        query = query.or(`name.ilike.%${searchTerm}%,phone.ilike.%${searchTerm}%`);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data as Customer[];
    },
  });

  const createCustomerMutation = useMutation({
    mutationFn: async (customerData: typeof customerForm) => {
      const { data, error } = await supabase
        .from('customers')
        .insert(customerData)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast({
        title: "গ্রাহক যোগ করা হয়েছে!",
        description: "নতুন গ্রাহক সফলভাবে যোগ করা হয়েছে।",
      });
      setShowAddDialog(false);
      resetForm();
      queryClient.invalidateQueries({ queryKey: ['customers'] });
    },
    onError: () => {
      toast({
        title: "ত্রুটি!",
        description: "গ্রাহক যোগ করতে সমস্যা হয়েছে।",
        variant: "destructive",
      });
    }
  });

  const updateCustomerMutation = useMutation({
    mutationFn: async ({ id, ...customerData }: { id: string } & typeof customerForm) => {
      const { data, error } = await supabase
        .from('customers')
        .update(customerData)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      toast({
        title: "গ্রাহক আপডেট করা হয়েছে!",
        description: "গ্রাহকের তথ্য সফলভাবে আপডেট করা হয়েছে।",
      });
      setEditingCustomer(null);
      resetForm();
      queryClient.invalidateQueries({ queryKey: ['customers'] });
    },
    onError: () => {
      toast({
        title: "ত্রুটি!",
        description: "গ্রাহক আপডেট করতে সমস্যা হয়েছে।",
        variant: "destructive",
      });
    }
  });

  const resetForm = () => {
    setCustomerForm({
      name: '',
      phone: '',
      address: ''
    });
  };

  const handleSubmit = () => {
    if (!customerForm.name.trim()) {
      toast({
        title: "ত্রুটি!",
        description: "গ্রাহকের নাম দিন।",
        variant: "destructive",
      });
      return;
    }

    if (editingCustomer) {
      updateCustomerMutation.mutate({ id: editingCustomer.id, ...customerForm });
    } else {
      createCustomerMutation.mutate(customerForm);
    }
  };

  const handleEdit = (customer: Customer) => {
    setEditingCustomer(customer);
    setCustomerForm({
      name: customer.name,
      phone: customer.phone || '',
      address: customer.address || ''
    });
    setShowAddDialog(true);
  };

  const handleDialogClose = () => {
    setShowAddDialog(false);
    setEditingCustomer(null);
    resetForm();
  };

  return (
    <Card className="pos-card border-0">
      <CardHeader>
        <CardTitle className="text-xl font-bold text-gray-800 bangla-text flex items-center">
          <Users className="w-5 h-5 mr-2" />
          গ্রাহক ব্যবস্থাপনা
        </CardTitle>
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="গ্রাহক খুঁজুন (নাম বা ফোন)"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bangla-text"
            />
          </div>
          <Dialog open={showAddDialog} onOpenChange={handleDialogClose}>
            <DialogTrigger asChild>
              <Button className="bangla-text">
                <Plus className="w-4 h-4 mr-2" />
                নতুন গ্রাহক
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle className="bangla-text">
                  {editingCustomer ? 'গ্রাহক সম্পাদনা' : 'নতুন গ্রাহক যোগ করুন'}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label className="bangla-text">নাম *</Label>
                  <Input
                    value={customerForm.name}
                    onChange={(e) => setCustomerForm({ ...customerForm, name: e.target.value })}
                    placeholder="গ্রাহকের নাম"
                    className="bangla-text"
                  />
                </div>
                <div>
                  <Label className="bangla-text">ফোন নম্বর</Label>
                  <Input
                    value={customerForm.phone}
                    onChange={(e) => setCustomerForm({ ...customerForm, phone: e.target.value })}
                    placeholder="ফোন নম্বর"
                  />
                </div>
                <div>
                  <Label className="bangla-text">ঠিকানা</Label>
                  <Input
                    value={customerForm.address}
                    onChange={(e) => setCustomerForm({ ...customerForm, address: e.target.value })}
                    placeholder="ঠিকানা"
                    className="bangla-text"
                  />
                </div>
                <Button 
                  onClick={handleSubmit} 
                  className="w-full bangla-text"
                  disabled={createCustomerMutation.isPending || updateCustomerMutation.isPending}
                >
                  <Users className="w-4 h-4 mr-2" />
                  {editingCustomer ? 'আপডেট করুন' : 'গ্রাহক যোগ করুন'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      
      <CardContent>
        {isLoading ? (
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
          </div>
        ) : customers.length === 0 ? (
          <div className="text-center py-8">
            <Users className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 bangla-text">কোনো গ্রাহক পাওয়া যায়নি</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {customers.map((customer) => (
              <Card key={customer.id} className="p-4 hover:shadow-md transition-shadow duration-200">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <h3 className="font-semibold bangla-text">{customer.name}</h3>
                  </div>
                  <Button
                    onClick={() => handleEdit(customer)}
                    variant="outline"
                    size="sm"
                  >
                    <Edit className="w-3 h-3" />
                  </Button>
                </div>
                
                <div className="space-y-2 text-sm">
                  {customer.phone && (
                    <div className="flex items-center text-gray-600">
                      <Phone className="w-3 h-3 mr-2" />
                      {customer.phone}
                    </div>
                  )}
                  {customer.address && (
                    <div className="flex items-center text-gray-600">
                      <MapPin className="w-3 h-3 mr-2" />
                      <span className="bangla-text">{customer.address}</span>
                    </div>
                  )}
                  {customer.current_balance > 0 && (
                    <div className="text-orange-600 font-semibold bangla-text">
                      বকেয়া: {customer.current_balance} টাকা
                    </div>
                  )}
                </div>
                
                <div className="mt-3 text-xs text-gray-500">
                  যোগ হয়েছে: {new Date(customer.created_at).toLocaleDateString('bn-BD')}
                </div>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default CustomerManager;
