import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import InvoiceHeader from './invoice/InvoiceHeader';
import CustomerInfoTable from './invoice/CustomerInfoTable';
import InvoiceItemsTable from './invoice/InvoiceItemsTable';
import InvoiceTotals from './invoice/InvoiceTotals';
import InvoiceActions from './invoice/InvoiceActions';
import InvoiceEditForm from './invoice/InvoiceEditForm';

interface InvoicePreviewProps {
  saleId: string;
  onClose: () => void;
  onNewSale: () => void;
}

const InvoicePreview = ({ saleId, onClose, onNewSale }: InvoicePreviewProps) => {
  const [isEditing, setIsEditing] = useState(false);
  const [isEditingItems, setIsEditingItems] = useState(false);
  const [editData, setEditData] = useState<any>({});
  const [editItems, setEditItems] = useState<any[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Function to convert English numbers to Bengali
  const toBengaliNumber = (num: number) => {
    const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return num.toString().replace(/\d/g, (digit) => bengaliDigits[parseInt(digit)]);
  };

  const { data: sale, isLoading } = useQuery({
    queryKey: ['sale', saleId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('sales')
        .select(`
          *,
          sale_items (
            id,
            product_name,
            quantity,
            unit_price,
            total_price
          ),
          customers (
            address
          )
        `)
        .eq('id', saleId)
        .single();

      if (error) throw error;
      return data;
    },
  });

  const updateSaleMutation = useMutation({
    mutationFn: async (updatedData: any) => {
      const { error } = await supabase
        .from('sales')
        .update(updatedData)
        .eq('id', saleId);

      if (error) throw error;
    },
    onSuccess: () => {
      toast({
        title: "সফল!",
        description: "ইনভয়েস আপডেট হয়েছে।",
      });
      setIsEditing(false);
      queryClient.invalidateQueries({ queryKey: ['sale', saleId] });
    },
    onError: (error) => {
      toast({
        title: "ত্রুটি!",
        description: "ইনভয়েস আপডেটে সমস্যা হয়েছে।",
        variant: "destructive",
      });
      console.error('Update error:', error);
    }
  });

  const updateItemsMutation = useMutation({
    mutationFn: async (items: any[]) => {
      // Delete existing items
      const { error: deleteError } = await supabase
        .from('sale_items')
        .delete()
        .eq('sale_id', saleId);

      if (deleteError) throw deleteError;

      // Insert updated items
      const { error: insertError } = await supabase
        .from('sale_items')
        .insert(items.map(item => ({
          sale_id: saleId,
          product_name: item.product_name,
          quantity: item.quantity,
          unit_price: item.unit_price,
          total_price: item.total_price
        })));

      if (insertError) throw insertError;

      // Update sale totals
      const subtotal = items.reduce((sum, item) => sum + item.total_price, 0);
      const discountAmount = sale?.discount_amount || 0;
      const totalAmount = subtotal - discountAmount;

      const { error: updateError } = await supabase
        .from('sales')
        .update({
          subtotal,
          total_amount: totalAmount,
          due_amount: totalAmount - (sale?.paid_amount || 0)
        })
        .eq('id', saleId);

      if (updateError) throw updateError;
    },
    onSuccess: () => {
      toast({
        title: "সফল!",
        description: "পণ্যের তালিকা আপডেট হয়েছে।",
      });
      setIsEditingItems(false);
      queryClient.invalidateQueries({ queryKey: ['sale', saleId] });
    },
    onError: (error) => {
      toast({
        title: "ত্রুটি!",
        description: "পণ্যের তালিকা আপডেটে সমস্যা হয়েছে।",
        variant: "destructive",
      });
      console.error('Items update error:', error);
    }
  });

  const deleteSaleMutation = useMutation({
    mutationFn: async () => {
      // Delete sale items first
      const { error: itemsError } = await supabase
        .from('sale_items')
        .delete()
        .eq('sale_id', saleId);

      if (itemsError) throw itemsError;

      // Delete payments
      const { error: paymentsError } = await supabase
        .from('payments')
        .delete()
        .eq('sale_id', saleId);

      if (paymentsError) throw paymentsError;

      // Delete sale
      const { error: saleError } = await supabase
        .from('sales')
        .delete()
        .eq('id', saleId);

      if (saleError) throw saleError;
    },
    onSuccess: () => {
      toast({
        title: "সফল!",
        description: "ইনভয়েস ডিলিট হয়েছে।",
      });
      onClose();
      queryClient.invalidateQueries({ queryKey: ['sales'] });
    },
    onError: (error) => {
      toast({
        title: "ত্রুটি!",
        description: "ইনভয়েস ডিলিটে সমস্যা হয়েছে।",
        variant: "destructive",
      });
      console.error('Delete error:', error);
    }
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!sale) {
    return (
      <div className="text-center py-8">
        <p className="text-gray-500 bangla-text">ইনভয়েস পাওয়া যায়নি</p>
      </div>
    );
  }

  const handlePrint = () => {
    // Get current date and time in Bengali
    const now = new Date();
    const bengaliDate = now.toLocaleDateString('bn-BD');
    const bengaliTime = now.toLocaleTimeString('bn-BD');
    
    // Add print-specific styles with print date and time
    const printStyles = `
      <style>
        @media print {
          @page {
            margin: 0.5in;
            size: A4;
          }
          
          body * {
            visibility: hidden;
          }
          
          .print-content, .print-content * {
            visibility: visible;
          }
          
          .print-content {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            background: white !important;
          }
          
          .print-hide {
            display: none !important;
          }
          
          .print-invoice {
            box-shadow: none !important;
            border: none !important;
            background: white !important;
          }
          
          .gradient-header {
            background: linear-gradient(135deg, #1e3a8a, #7c3aed, #3730a3) !important;
            -webkit-print-color-adjust: exact;
            color-adjust: exact;
          }
          
          .bg-gradient-to-r {
            -webkit-print-color-adjust: exact;
            color-adjust: exact;
          }
          
          /* Print footer with date and time */
          .print-content::after {
            content: "প্রিন্ট তারিখ: ${bengaliDate} সময়: ${bengaliTime}";
            position: fixed;
            bottom: 0.3in;
            left: 0.5in;
            font-size: 10px;
            color: #666;
            font-family: 'SolaimanLipi', serif;
            z-index: 9999;
          }
        }
      </style>
    `;
    
    // Add styles to head
    const styleElement = document.createElement('div');
    styleElement.innerHTML = printStyles;
    document.head.appendChild(styleElement);
    
    // Print
    window.print();
    
    // Remove styles after printing
    setTimeout(() => {
      document.head.removeChild(styleElement);
    }, 1000);
  };

  const handleDownload = () => {
    alert('PDF ডাউনলোড ফিচার শীঘ্রই আসছে!');
  };

  const handleEdit = () => {
    setEditData({
      customer_name: sale.customer_name || '',
      customer_phone: sale.customer_phone || '',
      notes: sale.notes || '',
      payment_method: sale.payment_method,
      paid_amount: sale.paid_amount,
      discount_amount: sale.discount_amount
    });
    setIsEditing(true);
  };

  const handleEditItems = () => {
    setEditItems([...sale.sale_items]);
    setIsEditingItems(true);
  };

  const handleSave = () => {
    const updatedSale = {
      ...editData,
      due_amount: sale.total_amount - editData.paid_amount,
      payment_status: editData.paid_amount >= sale.total_amount ? 'paid' : 
                     editData.paid_amount > 0 ? 'partial' : 'pending'
    };
    updateSaleMutation.mutate(updatedSale);
  };

  const handleSaveItems = () => {
    updateItemsMutation.mutate(editItems);
  };

  const handleDelete = () => {
    if (confirm('আপনি কি নিশ্চিত যে এই ইনভয়েসটি ডিলিট করতে চান?')) {
      deleteSaleMutation.mutate();
    }
  };

  const addNewItem = () => {
    setEditItems([...editItems, {
      id: Math.random().toString(),
      product_name: '',
      quantity: 1,
      unit_price: 0,
      total_price: 0
    }]);
  };

  const updateItem = (index: number, field: string, value: any) => {
    const updatedItems = [...editItems];
    updatedItems[index] = { ...updatedItems[index], [field]: value };
    
    if (field === 'quantity' || field === 'unit_price') {
      updatedItems[index].total_price = updatedItems[index].quantity * updatedItems[index].unit_price;
    }
    
    setEditItems(updatedItems);
  };

  const removeItem = (index: number) => {
    setEditItems(editItems.filter((_, i) => i !== index));
  };

  const updateEditData = (field: string, value: any) => {
    setEditData({ ...editData, [field]: value });
  };

  const handleCancel = () => {
    setIsEditing(false);
    setIsEditingItems(false);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <InvoiceActions
        isEditing={isEditing}
        isEditingItems={isEditingItems}
        onClose={onClose}
        onNewSale={onNewSale}
        onEdit={handleEdit}
        onEditItems={handleEditItems}
        onDelete={handleDelete}
        onPrint={handlePrint}
        onDownload={handleDownload}
        onSave={handleSave}
        onSaveItems={handleSaveItems}
        onCancel={handleCancel}
      />

      {/* Invoice Content - This will be printed */}
      <div className="print-content">
        <div className="bg-white shadow-2xl rounded-lg overflow-hidden border border-gray-200 print-invoice">
          <InvoiceHeader
            invoiceNumber={sale.invoice_number}
            createdAt={sale.created_at}
          />

          <div className="p-6">
            <CustomerInfoTable
              customerName={sale.customer_name}
              customerPhone={sale.customer_phone}
              customerAddress={sale.customers?.address}
            />

            {isEditing && (
              <InvoiceEditForm
                editData={editData}
                onUpdateData={updateEditData}
              />
            )}

            {/* Items Table - Removed title */}
            <div className="mb-6">
              <InvoiceItemsTable
                items={sale.sale_items}
                isEditing={isEditingItems}
                editItems={editItems}
                onUpdateItem={updateItem}
                onAddNewItem={addNewItem}
                onRemoveItem={removeItem}
              />
            </div>

            <InvoiceTotals
              subtotal={sale.subtotal}
              discountAmount={sale.discount_amount}
              totalAmount={sale.total_amount}
              paidAmount={sale.paid_amount}
              dueAmount={sale.due_amount}
              paymentStatus={sale.payment_status}
            />

            {/* Notes Section */}
            {sale.notes && (
              <div className="mt-6 bg-yellow-50 rounded-lg p-3 border border-yellow-200">
                <h4 className="font-semibold text-yellow-700 bangla-text mb-2">নোট</h4>
                <p className="text-gray-700 bangla-text text-sm">{sale.notes}</p>
              </div>
            )}

            {/* Footer */}
            <div className="mt-6 pt-4 border-t border-gray-200">
              <div className="text-center">
                <p className="text-gray-600 bangla-text mb-1 text-sm">
                  ধন্যবাদ আমাদের সাথে কেনাকাটা করার জন্য!
                </p>
                <p className="text-xs text-gray-500 bangla-text">
                  যেকোনো সমস্যার জন্য যোগাযোগ করুন
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvoicePreview;
