
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Search, User, Plus, UserPlus } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Database } from '@/integrations/supabase/types';

type CustomerFromDB = Database['public']['Tables']['customers']['Row'];

interface Customer {
  id: string;
  name: string;
  phone: string;
  address: string;
  credit_limit: number;
  current_balance: number;
}

interface CustomerSelectProps {
  onCustomerSelect: (customer: Customer | null) => void;
  selectedCustomer: Customer | null;
}

const CustomerSelect = ({ onCustomerSelect, selectedCustomer }: CustomerSelectProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showResults, setShowResults] = useState(false);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [customerForm, setCustomerForm] = useState({
    name: '',
    phone: '',
    address: ''
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: customers = [], isLoading } = useQuery({
    queryKey: ['customers-search', searchTerm],
    queryFn: async () => {
      if (!searchTerm.trim()) return [];
      
      const { data, error } = await supabase
        .from('customers')
        .select('*')
        .or(`name.ilike.%${searchTerm}%,phone.ilike.%${searchTerm}%`)
        .limit(10);

      if (error) throw error;
      
      // Transform the data to match our Customer interface
      return (data as CustomerFromDB[]).map(customer => ({
        id: customer.id,
        name: customer.name,
        phone: customer.phone || '',
        address: customer.address || '',
        credit_limit: customer.credit_limit || 0,
        current_balance: customer.current_balance || 0,
      })) as Customer[];
    },
    enabled: searchTerm.trim().length > 0,
  });

  const createCustomerMutation = useMutation({
    mutationFn: async (customerData: typeof customerForm) => {
      const { data, error } = await supabase
        .from('customers')
        .insert(customerData)
        .select()
        .single();

      if (error) throw error;
      
      // Transform the response to match our Customer interface
      const dbCustomer = data as CustomerFromDB;
      return {
        id: dbCustomer.id,
        name: dbCustomer.name,
        phone: dbCustomer.phone || '',
        address: dbCustomer.address || '',
        credit_limit: dbCustomer.credit_limit || 0,
        current_balance: dbCustomer.current_balance || 0,
      } as Customer;
    },
    onSuccess: (newCustomer) => {
      toast({
        title: "গ্রাহক যোগ করা হয়েছে!",
        description: "নতুন গ্রাহক সফলভাবে যোগ করা হয়েছে।",
      });
      onCustomerSelect(newCustomer);
      setShowAddDialog(false);
      resetForm();
      setSearchTerm('');
      setShowResults(false);
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      queryClient.invalidateQueries({ queryKey: ['customers-search'] });
    },
    onError: () => {
      toast({
        title: "ত্রুটি!",
        description: "গ্রাহক যোগ করতে সমস্যা হয়েছে।",
        variant: "destructive",
      });
    }
  });

  const resetForm = () => {
    setCustomerForm({
      name: '',
      phone: '',
      address: ''
    });
  };

  const handleCustomerSelect = (customer: Customer) => {
    onCustomerSelect(customer);
    setSearchTerm('');
    setShowResults(false);
  };

  const handleClearCustomer = () => {
    onCustomerSelect(null);
  };

  const handleAddNewCustomer = () => {
    // Pre-fill the form with search term if it looks like a name
    if (searchTerm.trim()) {
      setCustomerForm(prev => ({
        ...prev,
        name: searchTerm.trim()
      }));
    }
    setShowAddDialog(true);
    setShowResults(false);
  };

  const handleSubmit = () => {
    if (!customerForm.name.trim()) {
      toast({
        title: "ত্রুটি!",
        description: "গ্রাহকের নাম দিন।",
        variant: "destructive",
      });
      return;
    }

    createCustomerMutation.mutate(customerForm);
  };

  const handleDialogClose = () => {
    setShowAddDialog(false);
    resetForm();
  };

  return (
    <div className="space-y-4">
      {selectedCustomer ? (
        <Card className="p-4 bg-green-50 border-green-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                <User className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <h4 className="font-semibold bangla-text">{selectedCustomer.name}</h4>
                <p className="text-sm text-gray-600">{selectedCustomer.phone}</p>
              </div>
            </div>
            <Button
              onClick={handleClearCustomer}
              variant="outline"
              size="sm"
              className="bangla-text"
            >
              পরিবর্তন
            </Button>
          </div>
        </Card>
      ) : (
        <div className="relative">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="গ্রাহক খুঁজুন (নাম বা ফোন)"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setShowResults(e.target.value.length > 0);
              }}
              className="pl-10 bangla-text"
              onFocus={() => setShowResults(searchTerm.length > 0)}
            />
          </div>

          {/* Search Results */}
          {showResults && (
            <Card className="absolute top-full mt-1 w-full z-10 max-h-80 overflow-y-auto">
              {isLoading ? (
                <div className="p-4 text-center bangla-text">খোঁজা হচ্ছে...</div>
              ) : customers.length === 0 ? (
                <div className="p-4 space-y-3">
                  <div className="text-center text-gray-500 bangla-text">
                    কোনো গ্রাহক পাওয়া যায়নি
                  </div>
                  <Button
                    onClick={handleAddNewCustomer}
                    className="w-full bangla-text"
                    variant="outline"
                  >
                    <UserPlus className="w-4 h-4 mr-2" />
                    নতুন গ্রাহক যোগ করুন
                  </Button>
                </div>
              ) : (
                <div className="divide-y">
                  {customers.map((customer) => (
                    <div
                      key={customer.id}
                      className="p-3 hover:bg-gray-50 cursor-pointer"
                      onClick={() => handleCustomerSelect(customer)}
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                          <User className="w-4 h-4 text-blue-600" />
                        </div>
                        <div>
                          <h4 className="font-semibold bangla-text">{customer.name}</h4>
                          <p className="text-sm text-gray-600">{customer.phone}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                  <div className="p-3 border-t">
                    <Button
                      onClick={handleAddNewCustomer}
                      className="w-full bangla-text"
                      variant="outline"
                    >
                      <UserPlus className="w-4 h-4 mr-2" />
                      নতুন গ্রাহক যোগ করুন
                    </Button>
                  </div>
                </div>
              )}
            </Card>
          )}

          {/* Click outside to close */}
          {showResults && (
            <div
              className="fixed inset-0 z-5"
              onClick={() => setShowResults(false)}
            />
          )}
        </div>
      )}

      {/* Add Customer Dialog */}
      <Dialog open={showAddDialog} onOpenChange={handleDialogClose}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="bangla-text">নতুন গ্রাহক যোগ করুন</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="bangla-text">নাম *</Label>
              <Input
                value={customerForm.name}
                onChange={(e) => setCustomerForm({ ...customerForm, name: e.target.value })}
                placeholder="গ্রাহকের নাম"
                className="bangla-text"
              />
            </div>
            <div>
              <Label className="bangla-text">ফোন নম্বর</Label>
              <Input
                value={customerForm.phone}
                onChange={(e) => setCustomerForm({ ...customerForm, phone: e.target.value })}
                placeholder="ফোন নম্বর"
              />
            </div>
            <div>
              <Label className="bangla-text">ঠিকানা</Label>
              <Input
                value={customerForm.address}
                onChange={(e) => setCustomerForm({ ...customerForm, address: e.target.value })}
                placeholder="ঠিকানা"
                className="bangla-text"
              />
            </div>
            <Button 
              onClick={handleSubmit} 
              className="w-full bangla-text"
              disabled={createCustomerMutation.isPending}
            >
              <UserPlus className="w-4 h-4 mr-2" />
              গ্রাহক যোগ করুন
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CustomerSelect;
