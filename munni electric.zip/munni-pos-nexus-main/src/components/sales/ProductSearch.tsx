
import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Search, Package, Scan, Zap } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import BarcodeScanner from './BarcodeScanner';
import { useToast } from '@/hooks/use-toast';

interface Product {
  id: string;
  name: string;
  retail_price: number;
  wholesale_price: number;
  current_stock: number;
  unit: string;
  barcode: string;
  categories: { name: string } | null;
  brands: { name: string } | null;
}

interface ProductSearchProps {
  onProductSelect: (product: Product) => void;
}

const ProductSearch = ({ onProductSelect }: ProductSearchProps) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showResults, setShowResults] = useState(false);
  const [showBarcodeScanner, setShowBarcodeScanner] = useState(false);
  const { toast } = useToast();

  const { data: products = [], isLoading } = useQuery({
    queryKey: ['products-search', searchTerm],
    queryFn: async () => {
      if (!searchTerm.trim()) return [];
      
      const { data, error } = await supabase
        .from('products')
        .select(`
          id,
          name,
          retail_price,
          wholesale_price,
          current_stock,
          unit,
          barcode,
          categories (name),
          brands (name)
        `)
        .eq('is_active', true)
        .or(`name.ilike.%${searchTerm}%,barcode.ilike.%${searchTerm}%`)
        .limit(10);

      if (error) throw error;
      return data as Product[];
    },
    enabled: searchTerm.trim().length > 0,
  });

  const handleProductSelect = (product: Product) => {
    onProductSelect(product);
    setSearchTerm('');
    setShowResults(false);
    
    // Show success feedback
    toast({
      title: "পণ্য যোগ করা হয়েছে! ✅",
      description: `${product.name} ইনভয়েসে যোগ করা হয়েছে`,
    });
  };

  const handleBarcodeScanned = async (barcode: string) => {
    console.log('Scanned barcode:', barcode);
    
    try {
      const { data, error } = await supabase
        .from('products')
        .select(`
          id,
          name,
          retail_price,
          wholesale_price,
          current_stock,
          unit,
          barcode,
          categories (name),
          brands (name)
        `)
        .eq('is_active', true)
        .eq('barcode', barcode)
        .single();

      if (error) {
        console.error('Product search error:', error);
        toast({
          title: "পণ্য পাওয়া যায়নি ❌",
          description: `বারকোড ${barcode} এর জন্য কোনো পণ্য খুঁজে পাওয়া যায়নি।`,
          variant: "destructive",
        });
        return;
      }

      if (data) {
        // Automatically add the product
        handleProductSelect(data as Product);
        
        // Additional success toast for barcode scanning
        toast({
          title: "বারকোড স্ক্যান সফল! 🎉",
          description: `${data.name} স্বয়ংক্রিয়ভাবে ইনভয়েসে যোগ করা হয়েছে`,
        });
      }
    } catch (error) {
      console.error('Barcode search error:', error);
      toast({
        title: "এরর ⚠️",
        description: "বারকোড স্ক্যানে সমস্যা হয়েছে।",
        variant: "destructive",
      });
    }
  };

  const startQuickScan = () => {
    setShowBarcodeScanner(true);
    toast({
      title: "কুইক স্ক্যান শুরু! 📱",
      description: "ক্যামেরা চালু হচ্ছে...",
    });
  };

  return (
    <div className="relative">
      <div className="flex space-x-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            placeholder="পণ্য খুঁজুন (নাম বা বারকোড)"
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setShowResults(e.target.value.length > 0);
            }}
            className="pl-10 bangla-text"
            onFocus={() => setShowResults(searchTerm.length > 0)}
          />
        </div>
        <Button
          onClick={startQuickScan}
          className="bangla-text bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white font-semibold shadow-lg"
        >
          <Zap className="w-4 h-4 mr-2" />
          কুইক স্ক্যান
        </Button>
      </div>

      {/* Search Results */}
      {showResults && (
        <Card className="absolute top-full mt-1 w-full z-10 max-h-80 overflow-y-auto shadow-xl border-2">
          {isLoading ? (
            <div className="p-4 text-center bangla-text">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600 mx-auto mb-2"></div>
              খোঁজা হচ্ছে...
            </div>
          ) : products.length === 0 ? (
            <div className="p-4 text-center text-gray-500 bangla-text">
              <Package className="w-8 h-8 mx-auto mb-2 text-gray-400" />
              কোনো পণ্য পাওয়া যায়নি
            </div>
          ) : (
            <div className="divide-y">
              {products.map((product) => (
                <div
                  key={product.id}
                  className="p-3 hover:bg-gradient-to-r hover:from-blue-50 hover:to-purple-50 cursor-pointer transition-all duration-200"
                  onClick={() => handleProductSelect(product)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-r from-blue-100 to-purple-100 rounded-lg flex items-center justify-center">
                        <Package className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-semibold bangla-text text-gray-800">{product.name}</h4>
                        <p className="text-sm text-gray-600 bangla-text">
                          স্টক: {product.current_stock} {product.unit}
                        </p>
                        {product.categories && (
                          <p className="text-xs text-gray-500 bangla-text">
                            {product.categories.name}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm bangla-text">
                        <div className="font-semibold text-green-600">খুচরা: {product.retail_price} ৳</div>
                        <div className="font-semibold text-blue-600">পাইকারি: {product.wholesale_price} ৳</div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>
      )}

      {/* Click outside to close */}
      {showResults && (
        <div
          className="fixed inset-0 z-5"
          onClick={() => setShowResults(false)}
        />
      )}

      {/* Enhanced Barcode Scanner Modal */}
      <BarcodeScanner
        isOpen={showBarcodeScanner}
        onClose={() => setShowBarcodeScanner(false)}
        onScan={handleBarcodeScanned}
      />
    </div>
  );
};

export default ProductSearch;
