
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, FileText, Phone, MapPin, Eye, Calendar } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import InvoicePreview from './InvoicePreview';

interface DueCustomer {
  id: string;
  name: string;
  phone: string;
  address: string;
  current_balance: number;
  sales: Array<{
    id: string;
    invoice_number: string;
    total_amount: number;
    due_amount: number;
    created_at: string;
  }>;
}

const DueBillsManager = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSaleId, setSelectedSaleId] = useState<string | null>(null);

  // Function to convert English numbers to Bengali
  const toBengaliNumber = (num: number) => {
    const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return num.toString().replace(/\d/g, (digit) => bengaliDigits[parseInt(digit)]);
  };

  const { data: dueCustomers = [], isLoading } = useQuery({
    queryKey: ['due-customers', searchTerm],
    queryFn: async () => {
      // First get customers with current_balance > 0
      let customersQuery = supabase
        .from('customers')
        .select('id, name, phone, address, current_balance')
        .gt('current_balance', 0);

      if (searchTerm.trim()) {
        customersQuery = customersQuery.or(`name.ilike.%${searchTerm}%,phone.ilike.%${searchTerm}%`);
      }

      const { data: customers, error: customersError } = await customersQuery;
      if (customersError) throw customersError;

      // For each customer, get their due sales
      const dueCustomersWithSales: DueCustomer[] = [];
      
      for (const customer of customers || []) {
        const { data: sales, error: salesError } = await supabase
          .from('sales')
          .select('id, invoice_number, total_amount, due_amount, created_at')
          .eq('customer_id', customer.id)
          .gt('due_amount', 0)
          .order('created_at', { ascending: false });

        if (salesError) throw salesError;

        if (sales && sales.length > 0) {
          dueCustomersWithSales.push({
            ...customer,
            sales
          });
        }
      }

      return dueCustomersWithSales;
    },
  });

  if (selectedSaleId) {
    return (
      <InvoicePreview
        saleId={selectedSaleId}
        onClose={() => setSelectedSaleId(null)}
        onNewSale={() => setSelectedSaleId(null)}
      />
    );
  }

  return (
    <Card className="pos-card border-0">
      <CardHeader>
        <CardTitle className="text-xl font-bold text-gray-800 bangla-text flex items-center">
          <FileText className="w-5 h-5 mr-2" />
          বকেয়া বিল ব্যবস্থাপনা
        </CardTitle>
        <div className="flex items-center space-x-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="গ্রাহক খুঁজুন (নাম বা ফোন)"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 bangla-text"
            />
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        {isLoading ? (
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
          </div>
        ) : dueCustomers.length === 0 ? (
          <div className="text-center py-8">
            <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 bangla-text">কোনো বকেয়া বিল পাওয়া যায়নি</p>
          </div>
        ) : (
          <div className="space-y-6">
            {dueCustomers.map((customer) => (
              <Card key={customer.id} className="p-4 border-l-4 border-l-orange-500">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg bangla-text">{customer.name}</h3>
                    <div className="space-y-1 text-sm mt-2">
                      {customer.phone && (
                        <div className="flex items-center text-gray-600">
                          <Phone className="w-3 h-3 mr-2" />
                          {customer.phone}
                        </div>
                      )}
                      {customer.address && (
                        <div className="flex items-center text-gray-600">
                          <MapPin className="w-3 h-3 mr-2" />
                          <span className="bangla-text">{customer.address}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant="destructive" className="text-sm bangla-text">
                      মোট বকেয়া: {toBengaliNumber(customer.current_balance)} ৳
                    </Badge>
                  </div>
                </div>
                
                <div className="border-t pt-4">
                  <h4 className="font-medium bangla-text mb-3">বকেয়া ইনভয়েস সমূহ:</h4>
                  <div className="space-y-2">
                    {customer.sales.map((sale) => (
                      <div key={sale.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <Badge variant="outline" className="text-xs">
                            {sale.invoice_number}
                          </Badge>
                          <span className="text-sm text-gray-500 flex items-center">
                            <Calendar className="w-3 h-3 mr-1" />
                            {new Date(sale.created_at).toLocaleDateString('bn-BD')}
                          </span>
                        </div>
                        
                        <div className="flex items-center space-x-3">
                          <div className="text-right">
                            <div className="text-sm font-medium bangla-text">
                              মোট: {toBengaliNumber(sale.total_amount)} ৳
                            </div>
                            <div className="text-sm text-orange-600 bangla-text">
                              বকেয়া: {toBengaliNumber(sale.due_amount)} ৳
                            </div>
                          </div>
                          <Button
                            onClick={() => setSelectedSaleId(sale.id)}
                            variant="outline"
                            size="sm"
                            className="bangla-text"
                          >
                            <Eye className="w-3 h-3 mr-1" />
                            দেখুন
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default DueBillsManager;
