
import React, { useRef, useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Camera, X, Scan } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import jsQR from 'jsqr';

interface BarcodeScannerProps {
  isOpen: boolean;
  onClose: () => void;
  onScan: (barcode: string) => void;
}

const BarcodeScanner = ({ isOpen, onClose, onScan }: BarcodeScannerProps) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [lastScanTime, setLastScanTime] = useState(0);
  const { toast } = useToast();

  // Initialize camera when scanner opens
  useEffect(() => {
    if (isOpen && !stream) {
      startCamera();
    }
    
    return () => {
      stopScanning();
      if (stream) {
        stopCamera();
      }
    };
  }, [isOpen]);

  // Auto-start scanning when camera is ready
  useEffect(() => {
    if (stream && videoRef.current && !isScanning) {
      // Wait a bit for camera to initialize, then start scanning
      setTimeout(() => {
        startAutoScanning();
      }, 1000);
    }
  }, [stream]);

  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: 'environment', // Use back camera
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });
      
      setStream(mediaStream);
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        videoRef.current.play();
      }

      toast({
        title: "ক্যামেরা চালু হয়েছে",
        description: "বারকোড স্ক্যানিং শুরু হচ্ছে...",
      });
    } catch (error) {
      console.error('Camera access error:', error);
      toast({
        title: "ক্যামেরা এক্সেস এরর",
        description: "ক্যামেরা চালু করতে পারছি না। অনুমতি দিন।",
        variant: "destructive",
      });
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const startAutoScanning = () => {
    if (isScanning) return;
    
    setIsScanning(true);
    toast({
      title: "অটো স্ক্যানিং চালু",
      description: "বারকোডটি লাল বক্সের মধ্যে রাখুন",
    });

    // Scan every 200ms for better responsiveness
    intervalRef.current = setInterval(() => {
      performScan();
    }, 200);
  };

  const stopScanning = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setIsScanning(false);
  };

  const performScan = () => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');

    if (!context || video.readyState !== video.HAVE_ENOUGH_DATA) return;

    // Set canvas size to match video
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    // Draw current video frame to canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Get image data from canvas
    const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
    
    try {
      // Try to detect QR code or barcode
      const code = jsQR(imageData.data, imageData.width, imageData.height);
      
      if (code) {
        // Prevent multiple rapid scans of the same code
        const now = Date.now();
        if (now - lastScanTime > 2000) { // 2 second cooldown
          setLastScanTime(now);
          handleSuccessfulScan(code.data);
        }
      }
    } catch (error) {
      console.log('QR scan error:', error);
    }
  };

  const handleSuccessfulScan = (barcode: string) => {
    stopScanning();
    onScan(barcode);
    handleClose();
    
    toast({
      title: "বারকোড স্ক্যান সফল! ✅",
      description: `বারকোড: ${barcode} - পণ্য ইনভয়েসে যোগ করা হয়েছে`,
    });
  };

  const handleClose = () => {
    stopScanning();
    stopCamera();
    setLastScanTime(0);
    onClose();
  };

  const handleManualScan = () => {
    if (!isScanning) {
      startAutoScanning();
    } else {
      performScan();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="bangla-text flex items-center space-x-2">
            <Scan className="w-5 h-5" />
            <span>প্রকৃত বারকোড স্ক্যান</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
            <video
              ref={videoRef}
              className="w-full h-full object-cover"
              autoPlay
              playsInline
              muted
            />
            
            {/* Scanning overlay with animation */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="border-2 border-red-500 bg-transparent w-64 h-32 relative">
                {/* Corner markers */}
                <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-red-500"></div>
                <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-red-500"></div>
                <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-red-500"></div>
                <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-red-500"></div>
                
                {/* Scanning animation */}
                {isScanning && (
                  <>
                    <div className="absolute inset-0 bg-red-500 bg-opacity-20 animate-pulse"></div>
                    <div className="absolute top-0 left-0 right-0 h-1 bg-red-500 animate-bounce"></div>
                  </>
                )}
              </div>
            </div>

            {/* Status indicator */}
            <div className="absolute top-4 left-4 right-4 text-center">
              <div className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                isScanning 
                  ? 'bg-green-500 text-white animate-pulse' 
                  : 'bg-yellow-500 text-black'
              }`}>
                {isScanning ? '🔍 স্ক্যান করছি...' : '⏸️ স্ক্যান বন্ধ'}
              </div>
            </div>

            {/* Instructions */}
            <div className="absolute bottom-4 left-4 right-4 text-center text-white text-sm bangla-text">
              {isScanning 
                ? 'বারকোড/QR কোডটি লাল বক্সের মধ্যে রাখুন'
                : 'স্ক্যান শুরু করতে বাটন চাপুন'
              }
            </div>
          </div>

          <canvas ref={canvasRef} className="hidden" />

          <div className="flex space-x-2">
            <Button
              onClick={handleManualScan}
              disabled={!stream}
              className={`flex-1 bangla-text ${
                isScanning 
                  ? 'bg-orange-500 hover:bg-orange-600' 
                  : 'bg-green-500 hover:bg-green-600'
              }`}
            >
              <Camera className="w-4 h-4 mr-2" />
              {isScanning ? 'এখনই স্ক্যান করুন' : 'অটো স্ক্যান শুরু'}
            </Button>
            
            <Button
              onClick={handleClose}
              variant="outline"
              className="bangla-text"
            >
              <X className="w-4 h-4 mr-2" />
              বন্ধ
            </Button>
          </div>

          <div className="text-sm text-gray-600 text-center bangla-text">
            <p>📱 ক্যামেরা অনুমতি দিন এবং বারকোড/QR কোডটি ফ্রেমের মধ্যে রাখুন</p>
            <p className="text-xs mt-1 text-green-600 font-semibold">✅ এখন প্রকৃত বারকোড স্ক্যানিং কার্যকর!</p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default BarcodeScanner;
