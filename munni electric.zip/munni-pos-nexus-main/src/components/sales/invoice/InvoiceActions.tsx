
import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Edit, X, Printer, Download, Plus, Save } from 'lucide-react';

interface InvoiceActionsProps {
  isEditing: boolean;
  isEditingItems: boolean;
  onClose: () => void;
  onNewSale: () => void;
  onEdit: () => void;
  onEditItems: () => void;
  onDelete: () => void;
  onPrint: () => void;
  onDownload: () => void;
  onSave: () => void;
  onSaveItems: () => void;
  onCancel: () => void;
}

const InvoiceActions = ({
  isEditing,
  isEditingItems,
  onClose,
  onNewSale,
  onEdit,
  onEditItems,
  onDelete,
  onPrint,
  onDownload,
  onSave,
  onSaveItems,
  onCancel
}: InvoiceActionsProps) => {
  return (
    <div className="flex items-center justify-between mb-6 print-hide">
      <Button onClick={onClose} variant="outline" className="bangla-text">
        <ArrowLeft className="w-4 h-4 mr-2" />
        ফিরে যান
      </Button>
      <div className="flex space-x-2">
        {!isEditing && !isEditingItems ? (
          <>
            <Button onClick={onEdit} variant="outline" className="bangla-text">
              <Edit className="w-4 h-4 mr-2" />
              বিল এডিট
            </Button>
            <Button onClick={onEditItems} variant="outline" className="bangla-text">
              <Edit className="w-4 h-4 mr-2" />
              পণ্য এডিট
            </Button>
            <Button onClick={onDelete} variant="destructive" className="bangla-text">
              <X className="w-4 h-4 mr-2" />
              ডিলিট
            </Button>
            <Button onClick={onPrint} variant="outline" className="bangla-text">
              <Printer className="w-4 h-4 mr-2" />
              প্রিন্ট
            </Button>
            <Button onClick={onDownload} variant="outline" className="bangla-text">
              <Download className="w-4 h-4 mr-2" />
              ডাউনলোড
            </Button>
          </>
        ) : (
          <>
            <Button 
              onClick={isEditing ? onSave : onSaveItems} 
              className="bg-green-600 hover:bg-green-700 bangla-text"
            >
              <Save className="w-4 h-4 mr-2" />
              সেভ
            </Button>
            <Button 
              onClick={onCancel} 
              variant="outline" 
              className="bangla-text"
            >
              <X className="w-4 h-4 mr-2" />
              বাতিল
            </Button>
          </>
        )}
        <Button onClick={onNewSale} className="bg-green-600 hover:bg-green-700 bangla-text print-hide">
          <Plus className="w-4 h-4 mr-2" />
          নতুন বিক্রয়
        </Button>
      </div>
    </div>
  );
};

export default InvoiceActions;
