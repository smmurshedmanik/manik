
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, Trash2 } from 'lucide-react';

interface SaleItem {
  id: string;
  product_name: string;
  quantity: number;
  unit_price: number;
  total_price: number;
}

interface InvoiceItemsTableProps {
  items: SaleItem[];
  isEditing: boolean;
  editItems: SaleItem[];
  onUpdateItem: (index: number, field: string, value: any) => void;
  onAddNewItem: () => void;
  onRemoveItem: (index: number) => void;
}

const InvoiceItemsTable = ({ 
  items, 
  isEditing, 
  editItems, 
  onUpdateItem, 
  onAddNewItem, 
  onRemoveItem 
}: InvoiceItemsTableProps) => {
  // Function to convert English numbers to Bengali
  const toBengaliNumber = (num: number) => {
    const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return num.toString().replace(/\d/g, (digit) => bengaliDigits[parseInt(digit)]);
  };

  // Function to get gradient background color for rows
  const getRowGradient = (index: number) => {
    const gradients = [
      'bg-gradient-to-r from-blue-50 to-indigo-50',
      'bg-gradient-to-r from-purple-50 to-pink-50',
      'bg-gradient-to-r from-green-50 to-emerald-50',
      'bg-gradient-to-r from-yellow-50 to-orange-50',
      'bg-gradient-to-r from-red-50 to-rose-50',
      'bg-gradient-to-r from-gray-50 to-slate-50',
    ];
    return gradients[index % gradients.length];
  };

  if (isEditing) {
    return (
      <div className="space-y-4 print-hide">
        {editItems.map((item, index) => (
          <div key={index} className="grid grid-cols-1 md:grid-cols-6 gap-4 p-4 bg-gray-50 rounded-lg">
            <div>
              <label className="block text-sm font-semibold text-gray-700 bangla-text mb-1">ক্রমিক</label>
              <Input
                value={toBengaliNumber(index + 1)}
                readOnly
                className="bg-gray-100"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 bangla-text mb-1">পণ্যের নাম</label>
              <Input
                value={item.product_name}
                onChange={(e) => onUpdateItem(index, 'product_name', e.target.value)}
                placeholder="পণ্যের নাম"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 bangla-text mb-1">পরিমাণ</label>
              <Input
                type="number"
                value={item.quantity}
                onChange={(e) => onUpdateItem(index, 'quantity', Number(e.target.value))}
                placeholder="পরিমাণ"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 bangla-text mb-1">দর</label>
              <Input
                type="number"
                value={item.unit_price}
                onChange={(e) => onUpdateItem(index, 'unit_price', Number(e.target.value))}
                placeholder="দর"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 bangla-text mb-1">মোট</label>
              <Input
                value={item.total_price}
                readOnly
                className="bg-gray-100"
              />
            </div>
            <div className="flex items-end">
              <Button
                onClick={() => onRemoveItem(index)}
                variant="destructive"
                size="sm"
                className="w-full"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        ))}
        
        <Button onClick={onAddNewItem} variant="outline" className="w-full bangla-text">
          <Plus className="w-4 h-4 mr-2" />
          নতুন পণ্য যোগ করুন
        </Button>
      </div>
    );
  }

  return (
    <div className="overflow-hidden rounded-lg border border-gray-200">
      <table className="w-full">
        <thead>
          <tr className="bg-gradient-to-r from-gray-100 to-gray-200">
            <th className="p-4 text-center font-semibold text-gray-700 bangla-text border-b w-16">ক্রমিক</th>
            <th className="p-4 text-left font-semibold text-gray-700 bangla-text border-b">পণ্য</th>
            <th className="p-4 text-center font-semibold text-gray-700 bangla-text border-b">পরিমাণ</th>
            <th className="p-4 text-right font-semibold text-gray-700 bangla-text border-b">দর</th>
            <th className="p-4 text-right font-semibold text-gray-700 bangla-text border-b">মোট</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item: any, index: number) => (
            <tr key={item.id} className={getRowGradient(index)}>
              <td className="p-4 text-center font-semibold text-gray-600">
                {toBengaliNumber(index + 1)}
              </td>
              <td className="p-4 bangla-text font-medium">{item.product_name}</td>
              <td className="p-4 text-center font-semibold">{toBengaliNumber(item.quantity)}</td>
              <td className="p-4 text-right bangla-text">{toBengaliNumber(item.unit_price)} ৳</td>
              <td className="p-4 text-right font-semibold bangla-text">{toBengaliNumber(item.total_price)} ৳</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default InvoiceItemsTable;
