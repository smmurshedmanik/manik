
import React from 'react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

interface InvoiceEditFormProps {
  editData: {
    customer_name?: string;
    customer_phone?: string;
    notes?: string;
    payment_method?: string;
    paid_amount?: number;
    discount_amount?: number;
  };
  onUpdateData: (field: string, value: any) => void;
}

const InvoiceEditForm = ({ editData, onUpdateData }: InvoiceEditFormProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 print-hide">
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-semibold text-gray-700 bangla-text mb-2">গ্রাহকের নাম</label>
          <Input
            value={editData.customer_name || ''}
            onChange={(e) => onUpdateData('customer_name', e.target.value)}
            placeholder="গ্রাহকের নাম"
          />
        </div>
        <div>
          <label className="block text-sm font-semibold text-gray-700 bangla-text mb-2">ফোন নম্বর</label>
          <Input
            value={editData.customer_phone || ''}
            onChange={(e) => onUpdateData('customer_phone', e.target.value)}
            placeholder="ফোন নম্বর"
          />
        </div>
      </div>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-semibold text-gray-700 bangla-text mb-2">প্রদত্ত টাকা</label>
          <Input
            type="number"
            value={editData.paid_amount || ''}
            onChange={(e) => onUpdateData('paid_amount', Number(e.target.value))}
            placeholder="প্রদত্ত টাকা"
          />
        </div>
        <div>
          <label className="block text-sm font-semibold text-gray-700 bangla-text mb-2">নোট</label>
          <Textarea
            value={editData.notes || ''}
            onChange={(e) => onUpdateData('notes', e.target.value)}
            placeholder="অতিরিক্ত নোট"
            rows={3}
          />
        </div>
      </div>
    </div>
  );
};

export default InvoiceEditForm;
