
import React from 'react';

interface InvoiceHeaderProps {
  invoiceNumber: string;
  createdAt: string;
}

const InvoiceHeader = ({ invoiceNumber, createdAt }: InvoiceHeaderProps) => {
  // Function to convert English numbers to Bengali
  const toBengaliNumber = (num: number) => {
    const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return num.toString().replace(/\d/g, (digit) => bengaliDigits[parseInt(digit)]);
  };

  // Generate QR code data
  const generateQRCodeData = (invoiceNumber: string, createdAt: string) => {
    const qrData = {
      invoice: invoiceNumber,
      date: new Date(createdAt).toLocaleDateString('bn-BD'),
      shop: 'মেসার্স মুন্নী ইলেকট্রিক'
    };
    return encodeURIComponent(JSON.stringify(qrData));
  };

  const qrCodeData = generateQRCodeData(invoiceNumber, createdAt);
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${qrCodeData}`;

  return (
    <div className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 text-white p-8 gradient-header">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <h1 className="text-3xl font-bold bangla-text mb-2">মেসার্স মুন্নী ইলেকট্রিক</h1>
          <p className="text-blue-100 bangla-text">প্রো: মোক্তার আহমদ</p>
          <p className="text-blue-100 bangla-text">নতুন বাজার, বড় মহেশখালী, মহেশখালী, কক্সবাজার</p>
        </div>
        
        {/* QR Code and Invoice Number */}
        <div className="flex flex-col items-center space-y-2">
          <div className="bg-white/20 rounded-lg p-3 backdrop-blur-sm">
            <div className="bg-white rounded p-2">
              <img 
                src={qrCodeUrl} 
                alt="QR Code" 
                className="w-24 h-24"
                onError={(e) => {
                  e.currentTarget.style.display = 'none';
                }}
              />
            </div>
          </div>
          
          {/* Invoice Number below QR Code */}
          <div className="text-center">
            <p className="text-sm font-semibold">{invoiceNumber}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvoiceHeader;
