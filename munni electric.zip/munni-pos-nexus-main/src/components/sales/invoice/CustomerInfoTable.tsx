
import React from 'react';
import { Table, TableBody, TableCell, TableRow } from '@/components/ui/table';

interface CustomerInfoTableProps {
  customerName?: string;
  customerPhone?: string;
  customerAddress?: string;
}

const CustomerInfoTable = ({ customerName, customerPhone, customerAddress }: CustomerInfoTableProps) => {
  return (
    <div className="mb-6">
      <Table className="border border-gray-300">
        <TableBody>
          <TableRow>
            <TableCell className="font-semibold bangla-text border-r border-gray-300 bg-gray-50 w-24 py-2 text-sm">
              ক্রেতার নাম:
            </TableCell>
            <TableCell className="bangla-text py-2 text-sm">
              {customerName || 'ওয়াক-ইন কাস্টমার'}
            </TableCell>
          </TableRow>
          {customerAddress && (
            <TableRow>
              <TableCell className="font-semibold bangla-text border-r border-gray-300 bg-gray-50 w-24 py-2 text-sm">
                ঠিকানা:
              </TableCell>
              <TableCell className="bangla-text py-2 text-sm">
                {customerAddress}
              </TableCell>
            </TableRow>
          )}
          {customerPhone && (
            <TableRow>
              <TableCell className="font-semibold bangla-text border-r border-gray-300 bg-gray-50 w-24 py-2 text-sm">
                মোবাইল:
              </TableCell>
              <TableCell className="bangla-text py-2 text-sm">
                {customerPhone}
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>
  );
};

export default CustomerInfoTable;
