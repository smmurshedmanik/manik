
import React from 'react';
import { Badge } from '@/components/ui/badge';

interface SaleDetailsProps {
  createdAt: string;
  customerName?: string;
  customerPhone?: string;
  saleType: string;
}

const SaleDetails = ({ createdAt, customerName, customerPhone, saleType }: SaleDetailsProps) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 print-hide">
      {/* Date Section */}
      <div className="bg-gray-50 rounded-lg p-4">
        <h3 className="font-semibold text-gray-700 bangla-text mb-2">বিক্রয়ের তথ্য</h3>
        <p className="text-gray-600 bangla-text">
          তারিখ: {new Date(createdAt).toLocaleDateString('bn-BD')}
        </p>
        <p className="text-gray-600 bangla-text">
          সময়: {new Date(createdAt).toLocaleTimeString('bn-BD')}
        </p>
      </div>

      {/* Customer Info */}
      {customerName && (
        <div className="bg-blue-50 rounded-lg p-4 border-l-4 border-blue-500">
          <h3 className="font-semibold text-blue-700 bangla-text mb-3">গ্রাহকের তথ্য</h3>
          <div className="space-y-2">
            <div>
              <span className="text-sm text-blue-600 bangla-text">নাম: </span>
              <span className="font-semibold bangla-text">{customerName}</span>
            </div>
            {customerPhone && (
              <div>
                <span className="text-sm text-blue-600 bangla-text">ফোন: </span>
                <span className="font-semibold">{customerPhone}</span>
              </div>
            )}
            <Badge 
              variant={saleType === 'wholesale' ? 'default' : 'secondary'} 
              className="bangla-text mt-2"
            >
              {saleType === 'wholesale' ? 'পাইকারি' : 'খুচরা'} গ্রাহক
            </Badge>
          </div>
        </div>
      )}
    </div>
  );
};

export default SaleDetails;
