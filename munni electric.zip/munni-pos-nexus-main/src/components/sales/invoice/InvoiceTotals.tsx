
import React from 'react';
import { Badge } from '@/components/ui/badge';

interface InvoiceTotalsProps {
  subtotal: number;
  discountAmount: number;
  totalAmount: number;
  paidAmount: number;
  dueAmount: number;
  paymentStatus: string;
}

const InvoiceTotals = ({ 
  subtotal, 
  discountAmount, 
  totalAmount, 
  paidAmount, 
  dueAmount, 
  paymentStatus 
}: InvoiceTotalsProps) => {
  // Function to convert English numbers to Bengali
  const toBengaliNumber = (num: number) => {
    const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return num.toString().replace(/\d/g, (digit) => bengaliDigits[parseInt(digit)]);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div className="print-hide">
        {/* Payment Status - Hidden in print */}
        <div className="bg-gray-50 rounded-lg p-4">
          <h4 className="font-semibold text-gray-700 bangla-text mb-3">পেমেন্ট স্ট্যাটাস</h4>
          <Badge 
            variant={paymentStatus === 'paid' ? 'default' : paymentStatus === 'partial' ? 'secondary' : 'destructive'}
            className="bangla-text text-base px-4 py-2"
          >
            {paymentStatus === 'paid' && 'সম্পূর্ণ পরিশোধিত'}
            {paymentStatus === 'partial' && 'আংশিক পরিশোধিত'}
            {paymentStatus === 'pending' && 'পেমেন্ট বাকি'}
          </Badge>
        </div>
      </div>

      <div>
        {/* Amount Summary */}
        <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-lg p-6 border border-green-200">
          <h4 className="font-semibold text-green-700 bangla-text mb-4">টাকার হিসাব</h4>
          <div className="space-y-3">
            <div className="flex justify-between bangla-text">
              <span className="text-gray-600">সাবটোটাল:</span>
              <span className="font-semibold">{toBengaliNumber(subtotal)} ৳</span>
            </div>
            {discountAmount > 0 && (
              <div className="flex justify-between text-red-600 bangla-text">
                <span>ছাড়:</span>
                <span className="font-semibold">-{toBengaliNumber(discountAmount)} ৳</span>
              </div>
            )}
            <div className="border-t border-green-200 pt-3">
              <div className="flex justify-between font-bold text-xl bangla-text text-green-700">
                <span>মোট:</span>
                <span>{toBengaliNumber(totalAmount)} ৳</span>
              </div>
            </div>
            <div className="flex justify-between bangla-text text-green-600">
              <span>প্রদত্ত:</span>
              <span className="font-semibold">{toBengaliNumber(paidAmount)} ৳</span>
            </div>
            {dueAmount > 0 && (
              <div className="flex justify-between text-orange-600 font-semibold bangla-text bg-orange-50 p-2 rounded">
                <span>বকেয়া:</span>
                <span>{toBengaliNumber(dueAmount)} ৳</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default InvoiceTotals;
