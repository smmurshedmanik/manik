import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Search, Receipt, Eye, Calendar, TrendingUp } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import InvoicePreview from './InvoicePreview';

const SalesList = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSaleId, setSelectedSaleId] = useState<string | null>(null);
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);

  // Function to convert English numbers to Bengali
  const toBengaliNumber = (num: number) => {
    const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return num.toString().replace(/\d/g, (digit) => bengaliDigits[parseInt(digit)]);
  };

  const { data: sales = [], isLoading } = useQuery({
    queryKey: ['sales', searchTerm, selectedDate],
    queryFn: async () => {
      let query = supabase
        .from('sales')
        .select(`
          id,
          invoice_number,
          customer_name,
          customer_phone,
          sale_type,
          total_amount,
          paid_amount,
          due_amount,
          payment_status,
          payment_method,
          created_at
        `)
        .order('created_at', { ascending: false });

      // Filter by selected date
      if (selectedDate) {
        const startDate = new Date(selectedDate);
        const endDate = new Date(selectedDate);
        endDate.setDate(endDate.getDate() + 1);
        
        query = query
          .gte('created_at', startDate.toISOString())
          .lt('created_at', endDate.toISOString());
      }

      if (searchTerm.trim()) {
        query = query.or(`invoice_number.ilike.%${searchTerm}%,customer_name.ilike.%${searchTerm}%,customer_phone.ilike.%${searchTerm}%`);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
  });

  // Calculate daily total
  const dailyTotal = sales.reduce((sum, sale) => sum + sale.total_amount, 0);
  const dailyPaid = sales.reduce((sum, sale) => sum + sale.paid_amount, 0);
  const dailyDue = sales.reduce((sum, sale) => sum + sale.due_amount, 0);

  if (selectedSaleId) {
    return (
      <InvoicePreview
        saleId={selectedSaleId}
        onClose={() => setSelectedSaleId(null)}
        onNewSale={() => setSelectedSaleId(null)}
      />
    );
  }

  return (
    <div className="space-y-6">
      {/* Daily Summary Card */}
      <Card className="pos-card border-0 bg-gradient-to-r from-green-50 to-emerald-50">
        <CardHeader>
          <CardTitle className="text-lg font-bold text-green-700 bangla-text flex items-center">
            <TrendingUp className="w-5 h-5 mr-2" />
            আজকের বিক্রয় সারসংক্ষেপ
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600 bangla-text">
                {toBengaliNumber(sales.length)}টি
              </div>
              <div className="text-sm text-gray-600 bangla-text">মোট বিক্রয়</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600 bangla-text">
                ৳{toBengaliNumber(dailyTotal)}
              </div>
              <div className="text-sm text-gray-600 bangla-text">মোট বিক্রয় মূল্য</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600 bangla-text">
                ৳{toBengaliNumber(dailyPaid)}
              </div>
              <div className="text-sm text-gray-600 bangla-text">মোট প্রাপ্ত</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-orange-600 bangla-text">
                ৳{toBengaliNumber(dailyDue)}
              </div>
              <div className="text-sm text-gray-600 bangla-text">মোট বকেয়া</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Sales List Card */}
      <Card className="pos-card border-0">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-800 bangla-text flex items-center">
            <Receipt className="w-5 h-5 mr-2" />
            বিক্রয় তালিকা
          </CardTitle>
          <div className="flex flex-col sm:flex-row items-center space-y-2 sm:space-y-0 sm:space-x-4">
            <div className="flex-1 relative w-full">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="ইনভয়েস নং, গ্রাহক বা ফোন নম্বর দিয়ে খুঁজুন"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bangla-text"
              />
            </div>
            <div className="relative w-full sm:w-auto">
              <Calendar className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="pl-10 bangla-text w-full sm:w-auto"
              />
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          {isLoading ? (
            <div className="flex items-center justify-center h-32">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
            </div>
          ) : sales.length === 0 ? (
            <div className="text-center py-8">
              <Receipt className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500 bangla-text">নির্বাচিত তারিখে কোনো বিক্রয় পাওয়া যায়নি</p>
            </div>
          ) : (
            <div className="space-y-4">
              {sales.map((sale) => (
                <div key={sale.id} className="flex items-center justify-between p-4 bg-white/70 rounded-lg border border-gray-100 hover:shadow-md transition-shadow duration-200">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <Badge variant="outline" className="text-xs">{sale.invoice_number}</Badge>
                      <Badge 
                        variant={sale.sale_type === 'wholesale' ? 'default' : 'secondary'}
                        className="text-xs bangla-text"
                      >
                        {sale.sale_type === 'wholesale' ? 'পাইকারি' : 'খুচরা'}
                      </Badge>
                      <span className="text-sm text-gray-500 flex items-center">
                        <Calendar className="w-3 h-3 mr-1" />
                        {new Date(sale.created_at).toLocaleDateString('bn-BD')}
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
                      <div>
                        <h4 className="font-semibold bangla-text">
                          {sale.customer_name || 'ওয়াক-ইন গ্রাহক'}
                        </h4>
                        {sale.customer_phone && (
                          <p className="text-sm text-gray-600">{sale.customer_phone}</p>
                        )}
                      </div>
                      
                      <div className="text-center">
                        <div className="font-bold text-lg text-green-600 bangla-text">
                          {toBengaliNumber(sale.total_amount)} ৳
                        </div>
                        <div className="text-sm text-gray-600 bangla-text">
                          প্রদত্ত: {toBengaliNumber(sale.paid_amount)} ৳
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <Badge 
                          variant={
                            sale.payment_status === 'paid' ? 'default' : 
                            sale.payment_status === 'partial' ? 'secondary' : 
                            'destructive'
                          }
                          className="bangla-text"
                        >
                          {sale.payment_status === 'paid' && 'পরিশোধিত'}
                          {sale.payment_status === 'partial' && 'আংশিক'}
                          {sale.payment_status === 'pending' && 'বকেয়া'}
                        </Badge>
                        {sale.due_amount > 0 && (
                          <div className="text-sm text-orange-600 bangla-text mt-1">
                            বকেয়া: {toBengaliNumber(sale.due_amount)} ৳
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="ml-4">
                    <Button
                      onClick={() => setSelectedSaleId(sale.id)}
                      variant="outline"
                      size="sm"
                      className="bangla-text"
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      দেখুন
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default SalesList;
