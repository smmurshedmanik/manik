
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ShoppingCart, Scan, Plus, Minus, Trash2, Receipt } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import ProductSearch from './ProductSearch';
import InvoicePreview from './InvoicePreview';

interface SaleItem {
  id: string;
  product_id: string;
  name: string;
  price: number;
  quantity: number;
  total: number;
  retail_price: number;
  wholesale_price: number;
}

interface Customer {
  id: string;
  name: string;
  phone: string;
  address: string;
  credit_limit: number;
  current_balance: number;
}

interface NewSaleProps {
  onSuccess: () => void;
}

const NewSale = ({ onSuccess }: NewSaleProps) => {
  const [saleItems, setSaleItems] = useState<SaleItem[]>([]);
  const [customerName, setCustomerName] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [discountPercentage, setDiscountPercentage] = useState(0);
  const [discountAmount, setDiscountAmount] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'credit' | 'mobile' | 'card'>('cash');
  const [paidAmount, setPaidAmount] = useState(0);
  const [showInvoice, setShowInvoice] = useState(false);
  const [lastSaleId, setLastSaleId] = useState<string | null>(null);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Calculate totals (always use retail price)
  const subtotal = saleItems.reduce((sum, item) => sum + (item.retail_price * item.quantity), 0);
  const finalDiscountAmount = discountPercentage > 0 ? (subtotal * discountPercentage / 100) : discountAmount;
  const total = subtotal - finalDiscountAmount;
  const dueAmount = total - paidAmount;

  const addProduct = (product: any) => {
    const price = product.retail_price;
    const existingItem = saleItems.find(item => item.product_id === product.id);
    
    if (existingItem) {
      updateQuantity(existingItem.id, existingItem.quantity + 1);
    } else {
      const newItem: SaleItem = {
        id: Math.random().toString(36).substr(2, 9),
        product_id: product.id,
        name: product.name,
        price,
        quantity: 1,
        total: price,
        retail_price: product.retail_price,
        wholesale_price: product.wholesale_price
      };
      setSaleItems([...saleItems, newItem]);
    }
  };

  const updateQuantity = (itemId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      setSaleItems(items => items.filter(item => item.id !== itemId));
      return;
    }
    
    setSaleItems(items => items.map(item => 
      item.id === itemId 
        ? { ...item, quantity: newQuantity, total: item.retail_price * newQuantity }
        : item
    ));
  };

  const removeItem = (itemId: string) => {
    setSaleItems(items => items.filter(item => item.id !== itemId));
  };

  const createSaleMutation = useMutation({
    mutationFn: async (saleData: any) => {
      let customerId = null;

      // Create customer if name is provided
      if (customerName.trim()) {
        const { data: customer, error: customerError } = await supabase
          .from('customers')
          .insert({
            name: customerName.trim(),
            phone: customerPhone.trim() || null,
            address: customerAddress.trim() || null
          })
          .select()
          .single();

        if (customerError) {
          // If customer already exists with same name, try to get it
          const { data: existingCustomer } = await supabase
            .from('customers')
            .select('id')
            .eq('name', customerName.trim())
            .single();
          
          if (existingCustomer) {
            customerId = existingCustomer.id;
          }
        } else {
          customerId = customer.id;
        }
      }

      // Generate invoice number
      const { data: invoiceData, error: invoiceError } = await supabase
        .rpc('generate_invoice_number');
      
      if (invoiceError) throw invoiceError;

      // Create sale
      const { data: sale, error: saleError } = await supabase
        .from('sales')
        .insert({
          invoice_number: invoiceData,
          customer_id: customerId,
          customer_name: customerName.trim() || null,
          customer_phone: customerPhone.trim() || null,
          sale_type: 'retail',
          subtotal,
          discount_amount: finalDiscountAmount,
          discount_percentage: discountPercentage,
          total_amount: total,
          paid_amount: paidAmount,
          due_amount: dueAmount,
          payment_method: paymentMethod,
          payment_status: dueAmount > 0 ? 'partial' : 'paid'
        })
        .select()
        .single();

      if (saleError) throw saleError;

      // Create sale items
      const saleItemsData = saleItems.map(item => ({
        sale_id: sale.id,
        product_id: item.product_id,
        product_name: item.name,
        quantity: item.quantity,
        unit_price: item.retail_price,
        total_price: item.retail_price * item.quantity
      }));

      const { error: itemsError } = await supabase
        .from('sale_items')
        .insert(saleItemsData);

      if (itemsError) throw itemsError;

      // Create payment record if payment was made
      if (paidAmount > 0) {
        const { error: paymentError } = await supabase
          .from('payments')
          .insert({
            sale_id: sale.id,
            amount: paidAmount,
            payment_method: paymentMethod
          });

        if (paymentError) throw paymentError;
      }

      return sale;
    },
    onSuccess: (sale) => {
      toast({
        title: "বিক্রয় সম্পন্ন!",
        description: `ইনভয়েস নং: ${sale.invoice_number}`,
      });
      setLastSaleId(sale.id);
      setShowInvoice(true);
      queryClient.invalidateQueries({ queryKey: ['sales'] });
      queryClient.invalidateQueries({ queryKey: ['products'] });
      queryClient.invalidateQueries({ queryKey: ['customers'] });
    },
    onError: (error) => {
      toast({
        title: "ত্রুটি!",
        description: "বিক্রয় সংরক্ষণে সমস্যা হয়েছে।",
        variant: "destructive",
      });
      console.error('Sale creation error:', error);
    }
  });

  const resetSale = () => {
    setSaleItems([]);
    setCustomerName('');
    setCustomerAddress('');
    setCustomerPhone('');
    setDiscountPercentage(0);
    setDiscountAmount(0);
    setPaymentMethod('cash');
    setPaidAmount(0);
    setShowInvoice(false);
    setLastSaleId(null);
  };

  const completeSale = () => {
    if (saleItems.length === 0) {
      toast({
        title: "ত্রুটি!",
        description: "অন্তত একটি পণ্য যোগ করুন।",
        variant: "destructive",
      });
      return;
    }

    createSaleMutation.mutate({});
  };

  if (showInvoice && lastSaleId) {
    return (
      <InvoicePreview 
        saleId={lastSaleId} 
        onClose={() => setShowInvoice(false)}
        onNewSale={resetSale}
      />
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Product Selection */}
      <div className="lg:col-span-2">
        <Card className="pos-card border-0">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-gray-800 bangla-text flex items-center">
              <ShoppingCart className="w-5 h-5 mr-2" />
              পণ্য নির্বাচন
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ProductSearch onProductSelect={addProduct} />
            
            {/* Sale Items */}
            <div className="mt-6">
              <h3 className="text-lg font-semibold bangla-text mb-4">নির্বাচিত পণ্য</h3>
              {saleItems.length === 0 ? (
                <div className="text-center py-8 text-gray-500 bangla-text">
                  কোনো পণ্য নির্বাচিত হয়নি
                </div>
              ) : (
                <div className="space-y-3">
                  {saleItems.map(item => (
                    <div key={item.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex-1">
                        <h4 className="font-semibold bangla-text">{item.name}</h4>
                        <p className="text-sm text-gray-600 bangla-text">
                          {item.retail_price} ৳ প্রতি পিস
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => updateQuantity(item.id, item.quantity - 1)}
                        >
                          <Minus className="w-4 h-4" />
                        </Button>
                        <span className="w-12 text-center font-semibold">{item.quantity}</span>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => removeItem(item.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="ml-4 text-right">
                        <div className="font-bold bangla-text">{item.retail_price * item.quantity} ৳</div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Sale Summary */}
      <div>
        <Card className="pos-card border-0">
          <CardHeader>
            <CardTitle className="text-xl font-bold text-gray-800 bangla-text">
              বিক্রয় সারাংশ
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Customer Information */}
            <div className="space-y-3">
              <Label className="bangla-text">গ্রাহকের তথ্য</Label>
              <div>
                <Input
                  placeholder="গ্রাহকের নাম"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  className="bangla-text"
                />
              </div>
              <div>
                <Input
                  placeholder="ঠিকানা"
                  value={customerAddress}
                  onChange={(e) => setCustomerAddress(e.target.value)}
                  className="bangla-text"
                />
              </div>
              <div>
                <Input
                  placeholder="মোবাইল নম্বর"
                  value={customerPhone}
                  onChange={(e) => setCustomerPhone(e.target.value)}
                />
              </div>
            </div>

            {/* Discount */}
            <div className="space-y-2">
              <Label className="bangla-text">ছাড়</Label>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Input
                    type="number"
                    placeholder="% ছাড়"
                    value={discountPercentage || ''}
                    onChange={(e) => {
                      setDiscountPercentage(Number(e.target.value));
                      setDiscountAmount(0);
                    }}
                  />
                </div>
                <div>
                  <Input
                    type="number"
                    placeholder="৳ ছাড়"
                    value={discountAmount || ''}
                    onChange={(e) => {
                      setDiscountAmount(Number(e.target.value));
                      setDiscountPercentage(0);
                    }}
                  />
                </div>
              </div>
            </div>

            {/* Payment Method */}
            <div>
              <Label className="bangla-text">পেমেন্ট পদ্ধতি</Label>
              <Tabs value={paymentMethod} onValueChange={(value: 'cash' | 'credit' | 'mobile' | 'card') => setPaymentMethod(value)}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="cash" className="bangla-text">নগদ</TabsTrigger>
                  <TabsTrigger value="credit" className="bangla-text">ধার</TabsTrigger>
                </TabsList>
                <TabsList className="grid w-full grid-cols-2 mt-2">
                  <TabsTrigger value="mobile" className="bangla-text">মোবাইল</TabsTrigger>
                  <TabsTrigger value="card" className="bangla-text">কার্ড</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            {/* Paid Amount */}
            <div>
              <Label className="bangla-text">প্রদত্ত টাকা</Label>
              <Input
                type="number"
                value={paidAmount || ''}
                onChange={(e) => setPaidAmount(Number(e.target.value))}
                placeholder="প্রদত্ত টাকার পরিমাণ"
              />
            </div>

            {/* Totals */}
            <div className="space-y-2 pt-4 border-t">
              <div className="flex justify-between bangla-text">
                <span>সাবটোটাল:</span>
                <span>{subtotal} ৳</span>
              </div>
              {finalDiscountAmount > 0 && (
                <div className="flex justify-between text-red-600 bangla-text">
                  <span>ছাড়:</span>
                  <span>-{finalDiscountAmount} ৳</span>
                </div>
              )}
              <div className="flex justify-between font-bold text-lg bangla-text">
                <span>মোট:</span>
                <span>{total} ৳</span>
              </div>
              {dueAmount > 0 && (
                <div className="flex justify-between text-orange-600 bangla-text">
                  <span>বকেয়া:</span>
                  <span>{dueAmount} ৳</span>
                </div>
              )}
            </div>

            {/* Action Buttons */}
            <div className="space-y-2">
              <Button 
                onClick={completeSale} 
                className="w-full bg-green-600 hover:bg-green-700 bangla-text"
                disabled={createSaleMutation.isPending || saleItems.length === 0}
              >
                <Receipt className="w-4 h-4 mr-2" />
                বিক্রয় সম্পন্ন করুন
              </Button>
              <Button 
                onClick={resetSale} 
                variant="outline" 
                className="w-full bangla-text"
              >
                নতুন বিক্রয়
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default NewSale;
