
import React from 'react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import { User, LogOut, Settings } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const UserMenu = () => {
  const { userProfile, signOut } = useAuth();
  const { toast } = useToast();

  const handleSignOut = async () => {
    try {
      await signOut();
      toast({
        title: 'সফল!',
        description: 'সফলভাবে লগআউট হয়েছে',
      });
    } catch (error) {
      toast({
        title: 'ত্রুটি',
        description: 'লগআউট করতে সমস্যা হয়েছে',
        variant: 'destructive',
      });
    }
  };

  return (
    <div className="flex items-center space-x-3">
      <div className="text-right text-sm">
        <p className="bangla-text text-white font-medium">{userProfile?.full_name}</p>
        <p className="text-blue-100 bangla-text">
          {userProfile?.role === 'owner' ? 'মালিক' : 'কর্মচারী'}
        </p>
      </div>
      <Button variant="ghost" size="sm" className="text-white hover:bg-white/20">
        <User className="w-4 h-4 mr-2" />
        <span className="bangla-text">প্রোফাইল</span>
      </Button>
      <Button 
        variant="ghost" 
        size="sm" 
        className="text-white hover:bg-white/20"
        onClick={handleSignOut}
      >
        <LogOut className="w-4 h-4" />
      </Button>
    </div>
  );
};

export default UserMenu;
