
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  Users, 
  UserPlus, 
  Mail, 
  Phone, 
  Shield, 
  Edit, 
  Trash2,
  Plus
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';

interface User {
  id: string;
  full_name: string;
  email: string;
  phone: string;
  role: 'owner' | 'manager' | 'employee';
  status: 'active' | 'inactive';
  created_at: string;
}

const UserManagement = () => {
  const { toast } = useToast();
  const { userProfile } = useAuth();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  
  // Mock users data - in real app this would come from Supabase
  const [users, setUsers] = useState<User[]>([
    {
      id: '1',
      full_name: userProfile?.full_name || 'মালিক',
      email: userProfile?.email || 'owner@munneeelectric.com',
      phone: userProfile?.phone || '+৮৮০১৮৩৪-৫৪৪১৭৫',
      role: 'owner',
      status: 'active',
      created_at: new Date().toISOString()
    }
  ]);

  const [newUser, setNewUser] = useState({
    full_name: '',
    email: '',
    phone: '',
    role: 'employee' as 'owner' | 'manager' | 'employee'
  });

  const handleAddUser = async () => {
    if (!newUser.full_name || !newUser.email || !newUser.phone) {
      toast({
        title: 'ত্রুটি',
        description: 'সকল ক্ষেত্র পূরণ করুন',
        variant: 'destructive',
      });
      return;
    }

    setLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const user: User = {
        id: Math.random().toString(),
        ...newUser,
        status: 'active',
        created_at: new Date().toISOString()
      };
      
      setUsers([...users, user]);
      setNewUser({ full_name: '', email: '', phone: '', role: 'employee' });
      setIsAddDialogOpen(false);
      
      toast({
        title: 'সফল!',
        description: 'নতুন ব্যবহারকারী যুক্ত করা হয়েছে',
      });
    } catch (error) {
      toast({
        title: 'ত্রুটি',
        description: 'ব্যবহারকারী যুক্ত করতে সমস্যা হয়েছে',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const getRoleBadge = (role: string) => {
    const roleMap = {
      owner: { label: 'মালিক', variant: 'default' as const, color: 'bg-green-100 text-green-800' },
      manager: { label: 'ম্যানেজার', variant: 'secondary' as const, color: 'bg-blue-100 text-blue-800' },
      employee: { label: 'কর্মচারী', variant: 'outline' as const, color: 'bg-gray-100 text-gray-800' }
    };
    return roleMap[role as keyof typeof roleMap] || roleMap.employee;
  };

  return (
    <Card className="pos-card border-0 shadow-xl bg-gradient-to-br from-white to-purple-50/30">
      <CardHeader className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-t-lg">
        <CardTitle className="text-lg font-bold bangla-text flex items-center justify-between">
          <div className="flex items-center">
            <Users className="w-5 h-5 mr-2" />
            ব্যবহারকারী ব্যবস্থাপনা
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="secondary" size="sm" className="bangla-text">
                <Plus className="w-4 h-4 mr-1" />
                নতুন ব্যবহারকারী
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle className="bangla-text flex items-center">
                  <UserPlus className="w-5 h-5 mr-2" />
                  নতুন ব্যবহারকারী যুক্ত করুন
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label htmlFor="fullName" className="bangla-text font-semibold">পূর্ণ নাম *</Label>
                  <Input
                    id="fullName"
                    value={newUser.full_name}
                    onChange={(e) => setNewUser({...newUser, full_name: e.target.value})}
                    className="bangla-text"
                    placeholder="ব্যবহারকারীর নাম লিখুন"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="email" className="bangla-text font-semibold">ইমেইল *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={newUser.email}
                    onChange={(e) => setNewUser({...newUser, email: e.target.value})}
                    placeholder="user@example.com"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone" className="bangla-text font-semibold">ফোন নম্বর *</Label>
                  <Input
                    id="phone"
                    value={newUser.phone}
                    onChange={(e) => setNewUser({...newUser, phone: e.target.value})}
                    placeholder="+৮৮০১৭XXXXXXXX"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="bangla-text font-semibold">ভূমিকা *</Label>
                  <Select value={newUser.role} onValueChange={(value: 'owner' | 'manager' | 'employee') => setNewUser({...newUser, role: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="employee" className="bangla-text">কর্মচারী</SelectItem>
                      <SelectItem value="manager" className="bangla-text">ম্যানেজার</SelectItem>
                      <SelectItem value="owner" className="bangla-text">মালিক</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex space-x-2 pt-4">
                  <Button 
                    onClick={handleAddUser} 
                    disabled={loading} 
                    className="flex-1 bg-blue-600 hover:bg-blue-700 bangla-text"
                  >
                    {loading ? 'যুক্ত করা হচ্ছে...' : 'ব্যবহারকারী যুক্ত করুন'}
                  </Button>
                  <Button 
                    variant="outline" 
                    onClick={() => setIsAddDialogOpen(false)}
                    className="bangla-text"
                  >
                    বাতিল
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {users.map((user) => (
            <div key={user.id} className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-blue-50 border border-gray-200 rounded-xl hover:shadow-md transition-all duration-200">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                  {user.full_name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-semibold text-gray-800 bangla-text">{user.full_name}</h4>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <Mail className="w-3 h-3" />
                    <span>{user.email}</span>
                  </div>
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <Phone className="w-3 h-3" />
                    <span>{user.phone}</span>
                  </div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <div className="text-center">
                  <Badge className={`${getRoleBadge(user.role).color} bangla-text font-semibold`}>
                    {getRoleBadge(user.role).label}
                  </Badge>
                  <div className="flex items-center space-x-1 mt-1">
                    <div className={`w-2 h-2 rounded-full ${user.status === 'active' ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    <span className="text-xs text-gray-500 bangla-text">
                      {user.status === 'active' ? 'সক্রিয়' : 'নিষ্ক্রিয়'}
                    </span>
                  </div>
                </div>
                {user.role !== 'owner' && (
                  <div className="flex space-x-1">
                    <Button size="sm" variant="ghost" className="hover:bg-blue-100">
                      <Edit className="w-4 h-4 text-blue-600" />
                    </Button>
                    <Button size="sm" variant="ghost" className="hover:bg-red-100">
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </Button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default UserManagement;
