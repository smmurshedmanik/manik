import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, Package } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';

interface LowStockProduct {
  id: string;
  name: string;
  current_stock: number;
  min_stock: number;
  unit: string;
  categories: { name: string } | null;
}

const StockAlert = () => {
  const { data: lowStockItems, isLoading } = useQuery({
    queryKey: ['low-stock-products'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('products')
        .select(`
          id,
          name,
          current_stock,
          min_stock,
          unit,
          categories (name)
        `)
        .eq('is_active', true)
        .order('current_stock', { ascending: true });

      if (error) throw error;
      
      // Filter low stock items manually
      return (data as LowStockProduct[]).filter(item => item.current_stock <= item.min_stock);
    },
  });

  if (isLoading) {
    return (
      <Card className="pos-card border-0">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-800 bangla-text flex items-center">
            <AlertTriangle className="w-5 h-5 text-red-500 mr-2" />
            স্টক শেষ হওয়ার সতর্কতা
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-32">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-500"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="pos-card border-0">
      <CardHeader>
        <CardTitle className="text-xl font-bold text-gray-800 bangla-text flex items-center">
          <AlertTriangle className="w-5 h-5 text-red-500 mr-2" />
          স্টক শেষ হওয়ার সতর্কতা
          <Badge variant="destructive" className="ml-2 bangla-text">
            {lowStockItems?.length || 0} টি পণ্য
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!lowStockItems || lowStockItems.length === 0 ? (
          <div className="text-center py-8">
            <Package className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500 bangla-text">সব পণ্যের স্টক যথেষ্ট আছে</p>
          </div>
        ) : (
          <div className="space-y-3">
            {lowStockItems.map((item) => (
              <div key={item.id} className="flex items-center justify-between p-3 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                    <Package className="w-5 h-5 text-red-600" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800 bangla-text">{item.name}</h4>
                    <p className="text-sm text-gray-600 bangla-text">ক্যাটাগরি: {item.categories?.name || 'N/A'}</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-sm bangla-text">
                    <span className="text-red-600 font-bold">{item.current_stock}</span>
                    <span className="text-gray-500">/{item.min_stock} {item.unit}</span>
                  </div>
                  <Button size="sm" className="mt-1 bg-red-600 hover:bg-red-700 bangla-text">
                    অর্ডার দিন
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default StockAlert;
