
import React from 'react';

const TimeBasedGreeting = () => {
  const getTimeBasedGreeting = () => {
    const currentHour = new Date().getHours();
    
    if (currentHour >= 6 && currentHour < 12) {
      return 'শুভ সকাল';
    } else if (currentHour >= 12 && currentHour < 17) {
      return 'শুভ অপরাহ্ন';
    } else if (currentHour >= 17 && currentHour < 21) {
      return 'শুভ সন্ধ্যা';
    } else {
      return 'শুভ রাত্রি';
    }
  };

  return (
    <div>
      <h2 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-800 bangla-text mb-2">
        {getTimeBasedGreeting()}
      </h2>
      <p className="text-sm text-gray-600 bangla-text">
        দোকানের বিক্রয়, স্টক এবং পরিসংখ্যান
      </p>
    </div>
  );
};

export default TimeBasedGreeting;
