
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const RecentSales = () => {
  const recentSales = [
    {
      id: '#INV001',
      customer: 'মোঃ রহিম উদ্দিন',
      items: 'LED বাল্b ১০টি, সুইচ ৫টি',
      amount: '১,২৮০ ৳',
      time: '১০:৩০ AM',
      status: 'সম্পন্ন'
    },
    {
      id: '#INV002',
      customer: 'সালমা খাতুন',
      items: 'ফ্যান ১টি, তার ২০ মিটার',
      amount: '৩,৫৬০ ৳',
      time: '১১:১৫ AM',
      status: 'সম্পন্ন'
    },
    {
      id: '#INV003',
      customer: 'করিম মিয়া',
      items: 'পাইপ ফিটিং সেট',
      amount: '৮৭৫ ৳',
      time: '১২:০৫ PM',
      status: 'বকেয়া'
    },
    {
      id: '#INV004',
      customer: 'হাসনা বেগম',
      items: 'সিমেন্ট ২ বস্তা',
      amount: '১,৬০০ ৳',
      time: '১২:৪৫ PM',
      status: 'সম্পন্ন'
    }
  ];

  return (
    <Card className="pos-card border-0">
      <CardHeader>
        <CardTitle className="text-xl font-bold text-gray-800 bangla-text flex items-center justify-between">
          সাম্প্রতিক বিক্রয়
          <Badge variant="secondary" className="bangla-text">আজ ১২টি বিক্রয়</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentSales.map((sale, index) => (
            <div key={index} className="flex items-center justify-between p-4 bg-white/70 rounded-lg border border-gray-100 hover:shadow-md transition-shadow duration-200">
              <div className="flex-1">
                <div className="flex items-center space-x-2 mb-1">
                  <Badge variant="outline" className="text-xs">{sale.id}</Badge>
                  <span className="text-sm text-gray-500">{sale.time}</span>
                </div>
                <h4 className="font-semibold text-gray-800 bangla-text">{sale.customer}</h4>
                <p className="text-sm text-gray-600 bangla-text">{sale.items}</p>
              </div>
              <div className="text-right">
                <div className="font-bold text-lg text-green-600 bangla-text">{sale.amount}</div>
                <Badge 
                  variant={sale.status === 'সম্পন্ন' ? 'default' : 'destructive'}
                  className="bangla-text"
                >
                  {sale.status}
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default RecentSales;
