
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ShoppingCart, Package, Users, FileText, Settings, BarChart } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const QuickActions = () => {
  const navigate = useNavigate();

  const actions = [
    {
      title: 'নতুন বিক্রয়',
      description: 'পণ্য বিক্রয় করুন',
      icon: ShoppingCart,
      color: 'bg-gradient-to-r from-green-500 to-green-600',
      action: () => navigate('/sales')
    },
    {
      title: 'পণ্য ব্যবস্থাপনা',
      description: 'পণ্য ও স্টক পরিচালনা',
      icon: Package,
      color: 'bg-gradient-to-r from-blue-500 to-blue-600',
      action: () => navigate('/products')
    },
    {
      title: 'গ্রাহক তালিকা',
      description: 'গ্রাহক পরিচালনা',
      icon: Users,
      color: 'bg-gradient-to-r from-purple-500 to-purple-600',
      action: () => navigate('/sales?tab=customers')
    },
    {
      title: 'রিপোর্ট দেখুন',
      description: 'বিক্রয় রিপোর্ট',
      icon: BarChart,
      color: 'bg-gradient-to-r from-orange-500 to-orange-600',
      action: () => console.log('রিপোর্ট দেখুন')
    },
    {
      title: 'ইনভয়েস তৈরি',
      description: 'নতুন ইনভয়েস',
      icon: FileText,
      color: 'bg-gradient-to-r from-teal-500 to-teal-600',
      action: () => navigate('/sales')
    },
    {
      title: 'সেটিংস',
      description: 'সিস্টেম সেটিংস',
      icon: Settings,
      color: 'bg-gradient-to-r from-gray-500 to-gray-600',
      action: () => console.log('সেটিংস')
    }
  ];

  return (
    <Card className="pos-card border-0 mb-8">
      <CardHeader>
        <CardTitle className="text-xl font-bold text-gray-800 bangla-text">
          দ্রুত কাজের মেনু
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {actions.map((action, index) => (
            <Button
              key={index}
              onClick={action.action}
              className={`${action.color} text-white hover:scale-105 transition-all duration-300 h-auto py-4 px-3 flex flex-col items-center space-y-2 shadow-lg hover:shadow-xl`}
            >
              <action.icon className="w-6 h-6" />
              <div className="text-center">
                <div className="text-sm font-semibold bangla-text">{action.title}</div>
                <div className="text-xs opacity-90 bangla-text">{action.description}</div>
              </div>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default QuickActions;
