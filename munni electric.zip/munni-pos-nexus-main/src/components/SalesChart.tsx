
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const SalesChart = () => {
  const salesData = [
    { day: 'রবি', sales: 8400, profit: 1680 },
    { day: 'সোম', sales: 12300, profit: 2460 },
    { day: 'মঙ্গল', sales: 9800, profit: 1960 },
    { day: 'বুধ', sales: 15600, profit: 3120 },
    { day: 'বৃহঃ', sales: 11200, profit: 2240 },
    { day: 'শুক্র', sales: 13800, profit: 2760 },
    { day: 'শনি', sales: 16500, profit: 3300 }
  ];

  // Transform data for pie chart
  const profitData = salesData.map((item, index) => ({
    name: item.day,
    value: item.profit,
    color: `hsl(${index * 51}, 70%, 50%)` // Generate different colors for each segment
  }));

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8', '#82CA9D', '#FFC658'];

  // Function to convert English numbers to Bengali
  const toBengaliNumber = (num: number) => {
    const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return num.toString().replace(/\d/g, (digit) => bengaliDigits[parseInt(digit)]);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
      <Card className="pos-card border-0">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-800 bangla-text">
            সাপ্তাহিক বিক্রয়
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" className="bangla-text" />
              <YAxis />
              <Tooltip 
                formatter={(value, name) => [
                  `${toBengaliNumber(Number(value))} ৳`,
                  name === 'sales' ? 'বিক্রয়' : 'লাভ'
                ]}
                labelFormatter={(label) => `দিন: ${label}`}
              />
              <Bar dataKey="sales" fill="#4f46e5" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="pos-card border-0">
        <CardHeader>
          <CardTitle className="text-xl font-bold text-gray-800 bangla-text">
            লাভের ট্রেন্ড
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={profitData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, value }) => `${name}: ${toBengaliNumber(value)} ৳`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {profitData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                formatter={(value) => [`${toBengaliNumber(Number(value))} ৳`, 'লাভ']}
                labelFormatter={(label) => `দিন: ${label}`}
              />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
};

export default SalesChart;
