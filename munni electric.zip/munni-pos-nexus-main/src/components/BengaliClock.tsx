
import React, { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Clock, Calendar } from 'lucide-react';

const BengaliClock = () => {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatBengaliNumber = (num: number, padLength?: number): string => {
    const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    const numStr = padLength ? num.toString().padStart(padLength, '0') : num.toString();
    return numStr.split('').map(digit => bengaliDigits[parseInt(digit)]).join('');
  };

  const formatBengaliTime = (date: Date): string => {
    let hours = date.getHours();
    const minutes = formatBengaliNumber(date.getMinutes(), 2);
    const ampm = hours >= 12 ? 'PM' : 'AM';
    
    hours = hours % 12;
    hours = hours ? hours : 12; // 0 hour should be 12
    
    const formattedHours = formatBengaliNumber(hours, 2);
    return `${formattedHours}:${minutes} ${ampm}`;
  };

  const getBengaliDay = (date: Date): string => {
    const days = ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহ', 'শুক্র', 'শনি'];
    return days[date.getDay()];
  };

  const getBengaliDate = (date: Date): string => {
    const day = formatBengaliNumber(date.getDate());
    const month = formatBengaliNumber(date.getMonth() + 1);
    return `${day}/${month}`;
  };

  return (
    <Card className="bg-gradient-to-br from-white/20 to-white/10 border-white/20 text-white shadow-sm w-24 backdrop-blur-sm">
      <CardContent className="p-1.5 text-center">
        <div className="flex items-center justify-center gap-1 mb-1">
          <Clock className="w-2.5 h-2.5 text-white" />
          <span className="text-[9px] font-medium bangla-text">সময়</span>
        </div>
        <div className="text-xs font-bold text-white bangla-text mb-1">
          {formatBengaliTime(time)}
        </div>
        <div className="flex items-center justify-center gap-1">
          <Calendar className="w-2 h-2 text-white" />
          <div className="text-[8px] text-white bangla-text">
            {getBengaliDay(time)} {getBengaliDate(time)}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default BengaliClock;
