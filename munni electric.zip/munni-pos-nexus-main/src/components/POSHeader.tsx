
import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Menu, Home, Package, ShoppingCart, Users, BarChart3, Settings, LogOut, FileText } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/useAuth';
import BengaliClock from '@/components/BengaliClock';

const menuItems = [
  {
    title: 'ড্যাশবোর্ড',
    url: '/',
    icon: Home,
  },
  {
    title: 'পণ্য ব্যবস্থাপনা',
    url: '/products',
    icon: Package,
  },
  {
    title: 'বিক্রয় ব্যবস্থাপনা',
    url: '/sales',
    icon: ShoppingCart,
  },
  {
    title: 'গ্রাহক',
    url: '/customers',
    icon: Users,
  },
  {
    title: 'বকেয়া বিল',
    url: '/due-bills',
    icon: FileText,
  },
  {
    title: 'রিপোর্ট',
    url: '/reports',
    icon: BarChart3,
  },
  {
    title: 'সেটিংস',
    url: '/settings',
    icon: Settings,
  },
];

const POSHeader = () => {
  const navigate = useNavigate();
  const { signOut } = useAuth();

  const handleLogout = async () => {
    await signOut();
    navigate('/auth');
  };

  return (
    <header className="relative overflow-hidden bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-700 text-white shadow-lg">
      {/* New animated background pattern */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute w-full h-full bg-gradient-to-r from-transparent via-white/10 to-transparent transform -skew-x-12 animate-[slide-in-right_4s_ease-in-out_infinite]"></div>
          <div className="absolute w-full h-full bg-gradient-to-r from-transparent via-emerald-300/20 to-transparent transform -skew-x-12 animate-[slide-in-right_6s_ease-in-out_infinite_reverse]"></div>
        </div>
        {/* Floating geometric shapes */}
        <div className="absolute top-1/4 left-1/4 w-8 h-8 bg-white/10 rounded-full animate-pulse"></div>
        <div className="absolute top-3/4 right-1/4 w-6 h-6 bg-teal-300/20 rounded-full animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-3/4 w-4 h-4 bg-cyan-300/15 rounded-full animate-pulse delay-2000"></div>
      </div>
      
      <div className="w-full px-2 sm:px-4 py-2 sm:py-4 relative z-10">
        <div className="flex items-center justify-between gap-2">
          {/* Menu on the left */}
          <div className="flex items-center">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="p-1 sm:p-2 hover:bg-white/10 rounded-lg transition-all duration-300 text-white hover:text-white hover:scale-105"
                >
                  <Menu className="w-4 h-4 sm:w-6 sm:h-6" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent 
                align="start" 
                className="w-56 bg-white/95 backdrop-blur-sm shadow-xl border border-gray-200 z-50 rounded-xl"
              >
                <DropdownMenuLabel className="bangla-text text-gray-700 font-bold">
                  মূল মেনু
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                {menuItems.map((item) => (
                  <DropdownMenuItem key={item.title} asChild>
                    <Link 
                      to={item.url}
                      className="flex items-center space-x-3 px-3 py-3 bangla-text text-gray-700 hover:bg-gradient-to-r hover:from-emerald-50 hover:to-teal-50 cursor-pointer rounded-lg mx-1 transition-all duration-200 hover:scale-105"
                    >
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                    </Link>
                  </DropdownMenuItem>
                ))}
                <DropdownMenuSeparator />
                <DropdownMenuItem 
                  onClick={handleLogout}
                  className="flex items-center space-x-3 px-3 py-3 bangla-text text-red-600 hover:bg-red-50 cursor-pointer rounded-lg mx-1 transition-all duration-200 hover:scale-105"
                >
                  <LogOut className="w-4 h-4" />
                  <span>লগআউট</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
          
          {/* Shop Name in center */}
          <div className="flex-1 text-center">
            <Link to="/" className="hover:opacity-90 transition-all duration-300 hover:scale-105 block">
              <div className="text-center">
                <h1 className="text-sm sm:text-lg lg:text-xl font-bold bangla-text text-white leading-tight drop-shadow-lg">
                  মেসার্স মুন্নী ইলেকট্রিক
                </h1>
                <p className="text-xs sm:text-sm text-emerald-100 bangla-text drop-shadow">
                  প্রো: মোক্তার আহমদ
                </p>
                <p className="text-xs sm:text-sm text-emerald-100 bangla-text hidden sm:block drop-shadow">
                  নতুন বাজার, বড় মহেশখালী, মহেশখালী, কক্সবাজার
                </p>
              </div>
            </Link>
          </div>
          
          {/* Clock on the right */}
          <div className="flex items-center">
            <div className="scale-75">
              <BengaliClock />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default POSHeader;
