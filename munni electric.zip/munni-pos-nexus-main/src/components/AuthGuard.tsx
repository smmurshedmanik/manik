
import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';

interface AuthGuardProps {
  children: React.ReactNode;
  requireOwner?: boolean;
}

const AuthGuard = ({ children, requireOwner = false }: AuthGuardProps) => {
  const { user, userProfile, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600 bangla-text">লোড হচ্ছে...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  if (requireOwner && userProfile?.role !== 'owner') {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-red-600 bangla-text">অ্যাক্সেস নিষেধ</h1>
          <p className="mt-2 text-gray-600 bangla-text">এই পেজ শুধুমাত্র মালিকদের জন্য</p>
        </div>
      </div>
    );
  }

  return <>{children}</>;
};

export default AuthGuard;
