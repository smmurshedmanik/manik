
import React from 'react';
import { Button } from '@/components/ui/button';
import { Download, FileText } from 'lucide-react';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';

interface DownloadReportProps {
  title: string;
  data: any;
  fileName?: string;
}

const DownloadReport: React.FC<DownloadReportProps> = ({ 
  title, 
  data, 
  fileName = 'report' 
}) => {
  const generatePDF = async () => {
    // Create a temporary div for the report content
    const reportDiv = document.createElement('div');
    reportDiv.style.position = 'absolute';
    reportDiv.style.left = '-9999px';
    reportDiv.style.width = '210mm'; // A4 width
    reportDiv.style.minHeight = '297mm'; // A4 height
    reportDiv.style.backgroundColor = 'white';
    reportDiv.style.padding = '20mm';
    reportDiv.style.fontFamily = 'Arial, sans-serif';
    
    // Add watermark
    const watermarkStyle = `
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%) rotate(-45deg);
      font-size: 48px;
      color: rgba(0, 0, 0, 0.1);
      z-index: 1;
      pointer-events: none;
      white-space: nowrap;
      font-weight: bold;
    `;
    
    reportDiv.innerHTML = `
      <div style="${watermarkStyle}">
        মেসার্স মুন্নী ইলেকট্রিক
      </div>
      <div style="position: relative; z-index: 2;">
        <div style="text-align: center; margin-bottom: 30px; border-bottom: 2px solid #059669; padding-bottom: 20px;">
          <h1 style="color: #059669; font-size: 24px; margin: 0; font-weight: bold;">মেসার্স মুন্নী ইলেকট্রিক</h1>
          <p style="margin: 5px 0; color: #666; font-size: 14px;">প্রো: মোক্তার আহমদ</p>
          <p style="margin: 5px 0; color: #666; font-size: 12px;">নতুন বাজার, বড় মহেশখালী, মহেশখালী, কক্সবাজার</p>
          <p style="margin: 5px 0; color: #666; font-size: 12px;">ফোন: +৮৮০১৮৩৪-৫৪৪১৭৫</p>
        </div>
        
        <div style="margin-bottom: 20px;">
          <h2 style="color: #059669; font-size: 18px; margin-bottom: 15px; border-bottom: 1px solid #e5e7eb; padding-bottom: 5px;">${title}</h2>
          <p style="color: #666; font-size: 12px;">তারিখ: ${new Date().toLocaleDateString('bn-BD')}</p>
          <p style="color: #666; font-size: 12px;">সময়: ${new Date().toLocaleTimeString('bn-BD')}</p>
        </div>
        
        <div style="margin-bottom: 30px;">
          ${formatDataForPDF(data)}
        </div>
        
        <div style="margin-top: 40px; text-align: center; font-size: 10px; color: #666; border-top: 1px solid #e5e7eb; padding-top: 20px;">
          <p>এই রিপোর্টটি স্বয়ংক্রিয়ভাবে তৈরি হয়েছে - মেসার্স মুন্নী ইলেকট্রিক POS সিস্টেম</p>
          <p>© ২০২৫ মেসার্স মুন্নী ইলেকট্রিক - সর্বস্বত্ব সংরক্ষিত</p>
        </div>
      </div>
    `;
    
    document.body.appendChild(reportDiv);
    
    try {
      // Convert to canvas
      const canvas = await html2canvas(reportDiv, {
        scale: 2,
        useCORS: true,
        allowTaint: true,
        backgroundColor: '#ffffff'
      });
      
      // Create PDF
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgData = canvas.toDataURL('image/png');
      
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = pdf.internal.pageSize.getHeight();
      
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      
      // Download the PDF
      pdf.save(`${fileName}_${new Date().getTime()}.pdf`);
      
    } catch (error) {
      console.error('Error generating PDF:', error);
      alert('পিডিএফ তৈরি করতে সমস্যা হয়েছে। অনুগ্রহ করে আবার চেষ্টা করুন।');
    } finally {
      document.body.removeChild(reportDiv);
    }
  };

  const formatDataForPDF = (data: any): string => {
    if (Array.isArray(data)) {
      if (data.length === 0) {
        return '<p style="text-align: center; color: #666; font-style: italic;">কোন তথ্য পাওয়া যায়নি</p>';
      }
      
      // Create table for array data
      const headers = Object.keys(data[0] || {});
      let tableHTML = `
        <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
          <thead>
            <tr style="background-color: #f3f4f6;">
              ${headers.map(header => 
                `<th style="border: 1px solid #d1d5db; padding: 8px; text-align: left; font-weight: bold; color: #374151;">${header}</th>`
              ).join('')}
            </tr>
          </thead>
          <tbody>
      `;
      
      data.forEach((row, index) => {
        tableHTML += `
          <tr style="${index % 2 === 0 ? 'background-color: #f9fafb;' : ''}">
            ${headers.map(header => 
              `<td style="border: 1px solid #d1d5db; padding: 8px; color: #374151;">${row[header] || '-'}</td>`
            ).join('')}
          </tr>
        `;
      });
      
      tableHTML += '</tbody></table>';
      return tableHTML;
    } else if (typeof data === 'object') {
      // Format object data
      let objectHTML = '<div style="margin: 20px 0;">';
      Object.entries(data).forEach(([key, value]) => {
        objectHTML += `
          <div style="margin: 10px 0; display: flex; justify-content: space-between; align-items: center; padding: 8px; border-bottom: 1px solid #e5e7eb;">
            <strong style="color: #374151;">${key}:</strong>
            <span style="color: #6b7280;">${value}</span>
          </div>
        `;
      });
      objectHTML += '</div>';
      return objectHTML;
    } else {
      return `<p style="color: #374151; line-height: 1.6;">${data}</p>`;
    }
  };

  return (
    <Button
      onClick={generatePDF}
      className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105"
    >
      <Download className="w-4 h-4 mr-2" />
      <span className="bangla-text">পিডিএফ ডাউনলোড</span>
    </Button>
  );
};

export default DownloadReport;
