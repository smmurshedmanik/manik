
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ShoppingCart, Package, Users, Receipt, FileText, Settings, AlertTriangle, Download } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/integrations/supabase/client';
import StockAlert from '@/components/StockAlert';
import DownloadReport from '@/components/DownloadReport';

const DashboardStats = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('main-actions');

  // Function to convert English numbers to Bengali
  const toBengaliNumber = (num: number) => {
    const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return num.toString().replace(/\d/g, (digit) => bengaliDigits[parseInt(digit)]);
  };

  // Get today's sales total
  const { data: todaysSales = [] } = useQuery({
    queryKey: ['todays-sales-summary'],
    queryFn: async () => {
      const today = new Date();
      const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
      const endOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);
      
      const { data, error } = await supabase
        .from('sales')
        .select('total_amount')
        .gte('created_at', startOfDay.toISOString())
        .lt('created_at', endOfDay.toISOString());
      
      if (error) throw error;
      return data;
    },
  });

  // Get dashboard summary data for download
  const { data: dashboardData } = useQuery({
    queryKey: ['dashboard-summary'],
    queryFn: async () => {
      const today = new Date();
      const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
      
      const [salesData, productsData, customersData] = await Promise.all([
        supabase.from('sales').select('*').gte('created_at', startOfDay.toISOString()),
        supabase.from('products').select('*'),
        supabase.from('customers').select('*')
      ]);

      return {
        todaysSales: salesData.data || [],
        totalProducts: productsData.data?.length || 0,
        totalCustomers: customersData.data?.length || 0,
        todaysRevenue: todaysSales.reduce((sum, sale) => sum + sale.total_amount, 0)
      };
    },
  });

  const todaysTotal = todaysSales.reduce((sum, sale) => sum + sale.total_amount, 0);

  const actions = [
    {
      title: 'আজকের বিক্রয়',
      description: `৳${toBengaliNumber(todaysTotal)}`,
      icon: Receipt,
      color: 'bg-gradient-to-br from-emerald-500 via-emerald-600 to-green-600 shadow-lg hover:shadow-emerald-200',
      action: () => navigate('/sales?tab=sales-list')
    },
    {
      title: 'নতুন বিক্রয়',
      description: 'পণ্য বিক্রয় করুন',
      icon: ShoppingCart,
      color: 'bg-gradient-to-br from-green-500 via-green-600 to-emerald-600 shadow-lg hover:shadow-green-200',
      action: () => navigate('/sales')
    },
    {
      title: 'পণ্য ব্যবস্থাপনা',
      description: 'পণ্য ও স্টক পরিচালনা',
      icon: Package,
      color: 'bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-600 shadow-lg hover:shadow-blue-200',
      action: () => navigate('/products')
    },
    {
      title: 'গ্রাহক তালিকা',
      description: 'গ্রাহক পরিচালনা',
      icon: Users,
      color: 'bg-gradient-to-br from-purple-500 via-purple-600 to-violet-600 shadow-lg hover:shadow-purple-200',
      action: () => navigate('/customers')
    },
    {
      title: 'বকেয়া বিল',
      description: 'বকেয়া পেমেন্ট দেখুন',
      icon: FileText,
      color: 'bg-gradient-to-br from-orange-500 via-orange-600 to-amber-600 shadow-lg hover:shadow-orange-200',
      action: () => navigate('/due-bills')
    },
    {
      title: 'রিপোর্ট',
      description: 'বিক্রয় ও অ্যানালিটিক্স',
      icon: FileText,
      color: 'bg-gradient-to-br from-teal-500 via-teal-600 to-cyan-600 shadow-lg hover:shadow-teal-200',
      action: () => navigate('/reports')
    },
    {
      title: 'সেটিংস',
      description: 'সিস্টেম সেটিংস',
      icon: Settings,
      color: 'bg-gradient-to-br from-gray-500 via-gray-600 to-slate-600 shadow-lg hover:shadow-gray-200',
      action: () => navigate('/settings')
    },
    {
      title: 'স্টক আপডেট',
      description: 'স্টক সতর্কতা দেখুন',
      icon: AlertTriangle,
      color: 'bg-gradient-to-br from-red-500 via-red-600 to-rose-600 shadow-lg hover:shadow-red-200',
      action: () => setActiveTab('stock-update')
    }
  ];

  return (
    <Card className="pos-card border-0 shadow-xl bg-gradient-to-br from-white to-blue-50/30">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-center">
          <CardTitle className="bangla-text text-lg text-gray-700">মূল নিয়ন্ত্রণ প্যানেল</CardTitle>
          <DownloadReport 
            title="ড্যাশবোর্ড সারসংক্ষেপ রিপোর্ট"
            data={dashboardData}
            fileName="dashboard_summary"
          />
        </div>
      </CardHeader>
      <CardContent className="space-y-6 pt-2">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-gradient-to-r from-emerald-50 to-teal-50 shadow-lg rounded-xl border border-emerald-100">
            <TabsTrigger 
              value="main-actions" 
              className="bangla-text font-semibold transition-all duration-300 hover:scale-105 data-[state=active]:bg-gradient-to-r data-[state=active]:from-emerald-600 data-[state=active]:to-teal-600 data-[state=active]:text-white data-[state=active]:shadow-lg"
            >
              প্রধান মেনু
            </TabsTrigger>
            <TabsTrigger 
              value="stock-update" 
              className="bangla-text font-semibold transition-all duration-300 hover:scale-105 data-[state=active]:bg-gradient-to-r data-[state=active]:from-red-600 data-[state=active]:to-orange-600 data-[state=active]:text-white data-[state=active]:shadow-lg"
            >
              স্টক সতর্কতা
            </TabsTrigger>
          </TabsList>

          <TabsContent value="main-actions" className="mt-8">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-8 gap-4">
              {actions.map((action, index) => (
                <Button
                  key={index}
                  onClick={action.action}
                  className={`${action.color} text-white hover:scale-110 transition-all duration-300 h-auto py-6 px-4 flex flex-col items-center space-y-3 rounded-xl border-0`}
                >
                  <action.icon className="w-7 h-7 drop-shadow-sm" />
                  <div className="text-center">
                    <div className="text-sm font-bold bangla-text leading-tight">{action.title}</div>
                    <div className="text-xs opacity-90 bangla-text mt-1">{action.description}</div>
                  </div>
                </Button>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="stock-update" className="mt-8">
            <StockAlert />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default DashboardStats;
