
-- Create categories table
CREATE TABLE public.categories (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create brands table
CREATE TABLE public.brands (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create products table
CREATE TABLE public.products (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  category_id UUID REFERENCES public.categories(id),
  brand_id UUID REFERENCES public.brands(id),
  purchase_price DECIMAL(10,2) NOT NULL,
  retail_price DECIMAL(10,2) NOT NULL,
  wholesale_price DECIMAL(10,2) NOT NULL,
  current_stock INTEGER DEFAULT 0,
  min_stock INTEGER DEFAULT 10,
  unit TEXT DEFAULT 'পিস',
  barcode TEXT UNIQUE,
  is_active BOOLEAN DEFAULT true,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create stock movements table for tracking in/out
CREATE TABLE public.stock_movements (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID REFERENCES public.products(id) NOT NULL,
  movement_type TEXT NOT NULL CHECK (movement_type IN ('in', 'out')),
  quantity INTEGER NOT NULL,
  unit_price DECIMAL(10,2),
  total_price DECIMAL(10,2),
  reference_type TEXT, -- 'purchase', 'sale', 'adjustment', 'return'
  reference_id UUID,
  notes TEXT,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Create stock alerts table
CREATE TABLE public.stock_alerts (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id UUID REFERENCES public.products(id) NOT NULL,
  alert_type TEXT NOT NULL CHECK (alert_type IN ('low_stock', 'out_of_stock')),
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.brands ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock_movements ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stock_alerts ENABLE ROW LEVEL SECURITY;

-- RLS policies for categories
CREATE POLICY "Everyone can view categories" ON public.categories FOR SELECT TO authenticated USING (true);
CREATE POLICY "Only owners can manage categories" ON public.categories FOR ALL TO authenticated USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'owner')
);

-- RLS policies for brands
CREATE POLICY "Everyone can view brands" ON public.brands FOR SELECT TO authenticated USING (true);
CREATE POLICY "Only owners can manage brands" ON public.brands FOR ALL TO authenticated USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'owner')
);

-- RLS policies for products
CREATE POLICY "Everyone can view products" ON public.products FOR SELECT TO authenticated USING (true);
CREATE POLICY "Staff can create products" ON public.products FOR INSERT TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_active = true)
);
CREATE POLICY "Staff can update products" ON public.products FOR UPDATE TO authenticated USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_active = true)
);
CREATE POLICY "Only owners can delete products" ON public.products FOR DELETE TO authenticated USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'owner')
);

-- RLS policies for stock movements
CREATE POLICY "Everyone can view stock movements" ON public.stock_movements FOR SELECT TO authenticated USING (true);
CREATE POLICY "Staff can create stock movements" ON public.stock_movements FOR INSERT TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_active = true)
);

-- RLS policies for stock alerts
CREATE POLICY "Everyone can view stock alerts" ON public.stock_alerts FOR SELECT TO authenticated USING (true);
CREATE POLICY "Staff can manage stock alerts" ON public.stock_alerts FOR ALL TO authenticated USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_active = true)
);

-- Function to update product stock
CREATE OR REPLACE FUNCTION update_product_stock()
RETURNS TRIGGER AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    -- Update current stock based on movement type
    IF NEW.movement_type = 'in' THEN
      UPDATE public.products 
      SET current_stock = current_stock + NEW.quantity,
          updated_at = now()
      WHERE id = NEW.product_id;
    ELSIF NEW.movement_type = 'out' THEN
      UPDATE public.products 
      SET current_stock = current_stock - NEW.quantity,
          updated_at = now()
      WHERE id = NEW.product_id;
    END IF;
    
    -- Check for low stock and create alert
    INSERT INTO public.stock_alerts (product_id, alert_type)
    SELECT NEW.product_id, 
           CASE 
             WHEN current_stock <= 0 THEN 'out_of_stock'
             WHEN current_stock <= min_stock THEN 'low_stock'
           END
    FROM public.products 
    WHERE id = NEW.product_id 
      AND (current_stock <= 0 OR current_stock <= min_stock)
      AND NOT EXISTS (
        SELECT 1 FROM public.stock_alerts 
        WHERE product_id = NEW.product_id 
          AND is_read = false 
          AND alert_type IN ('low_stock', 'out_of_stock')
      );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for stock updates
CREATE TRIGGER trigger_update_product_stock
  AFTER INSERT ON public.stock_movements
  FOR EACH ROW EXECUTE FUNCTION update_product_stock();

-- Insert some default categories
INSERT INTO public.categories (name, description) VALUES
('বৈদ্যুতিক', 'বৈদ্যুতিক সামগ্রী'),
('স্যানিটারি', 'স্যানিটারি সামগ্রী'),
('হার্ডওয়্যার', 'হার্ডওয়্যার সামগ্রী'),
('পেইন্ট', 'পেইন্ট ও রং'),
('টুলস', 'যন্ত্রপাতি');

-- Insert some default brands
INSERT INTO public.brands (name, description) VALUES
('ফিলিপস', 'Philips'),
('ওয়ালটন', 'Walton'),
('প্রাণ-আরএফএল', 'PRAN-RFL'),
('বার্জার', 'Berger Paints'),
('এশিয়ান পেইন্টস', 'Asian Paints');
